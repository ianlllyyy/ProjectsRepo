<?php
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $taskId = $_POST['taskID'];
    $status = $_POST['status'];

    // Determine the new status based on the current status
    switch ($status) {
        case 'Submitted':
            $newStatus = 'In-Progress';
            break;
        case 'Late':
            $newStatus = 'Missing';
            break;
        case 'Revised':
            $newStatus = 'Revision';
            break;
        default:
            $newStatus = $status;
    }

    $query = "UPDATE tasks SET proof = NULL, proof_filename = NULL, status = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('si', $newStatus, $taskId);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $stmt->error]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}
?>