<?php
include 'db_connection.php';

if (isset($_GET['id']) && isset($_GET['type'])) {
    $id = intval($_GET['id']);
    $type = $_GET['type'];

    $column = ($type === 'attachment') ? 'attachment' : 'proof';
    $filenameColumn = ($type === 'attachment') ? 'attachment_filename' : 'proof_filename';
    $query = "SELECT $column, $filenameColumn FROM tasks WHERE id = ?";
    
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->bind_result($fileData, $filename);
        $stmt->fetch();
        $stmt->close();

        if ($fileData) {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mimeType = $finfo->buffer($fileData);

            header('Content-Type: ' . $mimeType);
            header('Content-Disposition: ' . (strpos($mimeType, 'image/') === 0 || $mimeType === 'application/pdf' ? 'inline' : 'attachment') . '; filename="' . $filename . '"');
            echo $fileData;
        } else {
            echo 'File not found.';
        }
    } else {
        echo 'Database error.';
    }
} else {
    echo 'Invalid request.';
}
$conn->close();
?>