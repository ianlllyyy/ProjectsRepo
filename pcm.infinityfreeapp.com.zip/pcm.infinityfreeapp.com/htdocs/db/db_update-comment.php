<?php
include 'db_connection.php';

$taskId = isset($_POST['task_id']) ? intval($_POST['task_id']) : 0;
$comment = isset($_POST['comment']) ? $_POST['comment'] : '';

if ($taskId > 0 && !empty($comment)) {
    // Check if proof is not NULL
    $proofCheckQuery = "SELECT proof FROM tasks WHERE id = ?";
    if ($proofStmt = $conn->prepare($proofCheckQuery)) {
        $proofStmt->bind_param('i', $taskId);
        $proofStmt->execute();
        $proofStmt->bind_result($proof);
        $proofStmt->fetch();
        $proofStmt->close();

        if (!empty($proof)) {
            // Update comment and set status to 'Revise'
            $query = "UPDATE tasks SET comments = ?, status = 'Revision' WHERE id = ?";
        } else {
            // Update comment only
            $query = "UPDATE tasks SET comments = ? WHERE id = ?";
        }

        if ($stmt = $conn->prepare($query)) {
            $stmt->bind_param('si', $comment, $taskId);
            if ($stmt->execute()) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => $stmt->error]);
            }
            $stmt->close();
        } else {
            echo json_encode(['success' => false, 'error' => 'Database error: ' . $conn->error]);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $conn->error]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid task ID or comment']);
}

$conn->close();
?>