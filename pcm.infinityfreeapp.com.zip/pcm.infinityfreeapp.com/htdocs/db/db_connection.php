<?php
$servername = "sql111.infinityfree.com";
$username = "if0_39786713";
$password = "paykuelfman3511";
$dbname = "if0_39786713_pcm_taskplanner";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>