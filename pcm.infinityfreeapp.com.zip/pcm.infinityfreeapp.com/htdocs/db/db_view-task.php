<?php
include 'db_connection.php';
$task_id = intval($_POST['task_id']);  // Changed $taskId to $task_id to match the variable used below

$query = "SELECT tasks.*, users.fullname AS assigned_to FROM tasks LEFT JOIN users ON tasks.assignedto = users.id WHERE tasks.id = ?";
if ($stmt = $conn->prepare($query)) {
    $stmt->bind_param('i', $task_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $task = $result->fetch_assoc();
        
        // Fix UTF-8 encoding issues
        array_walk_recursive($task, function(&$item) {
            if (is_string($item)) {
                // Try to detect encoding and convert to UTF-8
                $encoding = mb_detect_encoding($item, ['UTF-8', 'ISO-8859-1', 'ASCII', 'Windows-1252'], true);
                if ($encoding) {
                    $item = mb_convert_encoding($item, 'UTF-8', $encoding);
                } else {
                    // If encoding can't be detected, force UTF-8
                    $item = mb_convert_encoding($item, 'UTF-8', 'UTF-8');
                }
            }
        });
        
        // Use JSON_INVALID_UTF8_SUBSTITUTE flag to handle any remaining issues
        // Removed JSON_PRETTY_PRINT for cleaner output to JavaScript
        $json_output = json_encode($task, JSON_INVALID_UTF8_SUBSTITUTE);
        if ($json_output === false) {
            echo json_encode(['error' => 'JSON encoding error']);  // Structured error for JS
        } else {
            echo $json_output;
        }
    } else {
        echo json_encode(['error' => 'Task not found']);
    }
    $stmt->close();
} else {
    echo json_encode(['error' => 'Database error']);
}
$conn->close();
?>