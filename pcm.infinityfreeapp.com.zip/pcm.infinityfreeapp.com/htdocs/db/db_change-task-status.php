<?php
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $taskId = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $action = isset($_POST['action']) ? $_POST['action'] : '';

    if ($taskId > 0 && !empty($action)) {
        switch ($action) {
            case 'archive':
                $query = "UPDATE tasks SET status = 'Archived' WHERE id = ?";
                break;
            case 'delete':
                $query = "DELETE FROM tasks WHERE id = ?";
                break;
            case 'complete':
                $query = "UPDATE tasks SET status = 'Completed' WHERE id = ?";
                break;
            case 'restore':
                $query = "UPDATE tasks SET status = 'Completed' WHERE id = ?";
                break;
            case 'in-progress':
                $query = "UPDATE tasks SET status = 'In-Progress' WHERE id = ?";
                break;
            default:
                echo json_encode(['success' => false, 'message' => 'Invalid action']);
                exit;
        }

        if ($stmt = $conn->prepare($query)) {
            $stmt->bind_param('i', $taskId);
            if ($stmt->execute()) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Database error']);
            }
            $stmt->close();
        } else {
            echo json_encode(['success' => false, 'message' => 'Database error']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid input']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>