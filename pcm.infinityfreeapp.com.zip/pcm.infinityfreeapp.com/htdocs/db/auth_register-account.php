<?php
include 'db_connection.php';
require '../vendor/autoload.php'; // Load PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Function to generate a random password
function generateRandomPassword($length = 8) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomPassword = '';
    for ($i = 0; $i < $length; $i++) {
        $randomPassword .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomPassword;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstname = trim($_POST['firstname']);
    $middleinit = trim($_POST['middleinit']);
    $lastname  = trim($_POST['lastname']);
    $username   = trim($_POST['username']);
    $university = trim($_POST['university']);
    $email      = trim($_POST['email']);
    $department = isset($_POST['department']) ? trim($_POST['department']) : null;
    $gender     = isset($_POST['gender']) ? trim($_POST['gender']) : null;

    // Check if password is provided in the request body
    if (isset($_POST['password']) && !empty($_POST['password'])) {
        $position = 'Intern';
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    } else {
        $position = isset($_POST['position']) ? trim($_POST['position']) : 'Intern';
        $randomPassword = generateRandomPassword();
        $password = password_hash($randomPassword, PASSWORD_DEFAULT);
    }

    // Combine names
    $fullname = $firstname . ' ' . $middleinit . '. ' . $lastname;

    // Check if email or username already exists
    $check_user = $conn->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
    $check_user->bind_param("ss", $email, $username);
    $check_user->execute();
    $result = $check_user->get_result();

    if ($result->num_rows > 0) {
        echo "Email or username already registered!";
        exit();
    }

    // Set default profile picture
    $defaultPfpPath = '../img/default-profile.png';
    $pfp = file_get_contents($defaultPfpPath);

    $stmt = $conn->prepare("INSERT INTO users (fullname, username, university, email, department, gender, position, password, pfp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("sssssssss", $fullname, $username, $university, $email, $department, $gender, $position, $password, $pfp);

    if ($stmt->execute()) {
        // If a random password was generated, email it to the user
        if (!isset($_POST['password']) || empty($_POST['password'])) {
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host       = 'smtp-relay.brevo.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = '881e6f001@smtp-brevo.com';
                $mail->Password   = 'DUdcLHzJTvW8pFVZ';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;

                $mail->setFrom('klydel0219@gmail.com', 'PCM Task Planner');
                $mail->addAddress($email);

                $mail->Subject = 'Your New Account Password';
                $mail->Body    = "Hello $fullname,\n\nYour account has been created. Your password is: $randomPassword\n\nPlease change your password after logging in.";

                $mail->send();
                echo "Account created successfully.";
            } catch (Exception $e) {
                echo "Error sending email: " . $mail->ErrorInfo;
            }
        } else {
            echo "Account created successfully.";
        }
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close connections
    $stmt->close();
    $check_user->close();
}
$conn->close();
?>