<?php
include 'db_connection.php';

$taskId = isset($_POST['task_id']) ? intval($_POST['task_id']) : 0;
$taskName = $_POST['taskName'];
$taskDescription = $_POST['taskDescription'];
$assignedTo = $_POST['assignTo'];
$dueTime = $_POST['dueTime'];
$status = 'Pending';

$attachment = null;
$attachmentFilename = null;

if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] == UPLOAD_ERR_OK) {
    $attachment = file_get_contents($_FILES['attachment']['tmp_name']);
    $attachmentFilename = $_FILES['attachment']['name'];
} else {
    // Fetch existing attachment and filename if no new file is uploaded
    $query = "SELECT attachment, attachment_filename FROM tasks WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $taskId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $attachment = $row['attachment'];
        $attachmentFilename = $row['attachment_filename'];
    }
    $stmt->close();
}

date_default_timezone_set('Asia/Singapore'); // GMT+8
$startTime = date('Y-m-d H:i:s');

$query = "UPDATE tasks SET taskname = ?, taskdescription = ?, starttime = ?, duetime = ?, assignedto = ?, status = ?, attachment = ?, attachment_filename = ? WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('ssssisssi', $taskName, $taskDescription, $startTime, $dueTime, $assignedTo, $status, $attachment, $attachmentFilename, $taskId);

$response = ['success' => false];

if ($stmt->execute()) {
    $response['success'] = true;
}

$stmt->close();
$conn->close();

echo json_encode($response);
?>