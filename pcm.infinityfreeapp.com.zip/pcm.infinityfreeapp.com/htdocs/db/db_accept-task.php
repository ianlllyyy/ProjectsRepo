<?php
// filepath: c:\xampp\htdocs\taskplannerV2\db\update_task_status.php
include 'db_connection.php';

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the task ID from the POST request
    $task_id = $_POST['task_id'];

    // Prepare the SQL query to update the task status
    $query = "UPDATE tasks SET status = 'in-progress' WHERE id = ?";

    // Prepare and execute the statement
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param('i', $task_id);
        if ($stmt->execute()) {
            // Status updated successfully
            echo json_encode(['success' => true]);
        } else {
            // SQL error
            echo json_encode(['success' => false, 'error' => 'SQL error: ' . $stmt->error]);
        }
        $stmt->close();
    } else {
        // SQL error
        echo json_encode(['success' => false, 'error' => 'SQL error: ' . $conn->error]);
    }

    $conn->close();
} else {
    // Invalid request method
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}
?>