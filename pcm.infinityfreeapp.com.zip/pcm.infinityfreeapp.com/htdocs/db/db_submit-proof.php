<?php
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $taskId = $_POST['taskID'];

    if (!isset($_FILES['proofSubmit']) || $_FILES['proofSubmit']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['success' => false, 'error' => 'File upload failed.']);
        exit;
    }

    // Read the file contents
    $proof = file_get_contents($_FILES['proofSubmit']['tmp_name']);
    $proofFilename = $_FILES['proofSubmit']['name'];

    // Get the current status of the task
    $query = "SELECT status FROM tasks WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $taskId);
    $stmt->execute();
    $result = $stmt->get_result();
    $task = $result->fetch_assoc();
    $currentStatus = $task['status'];
    $stmt->close();

    // Determine the new status based on the current status
    switch ($currentStatus) {
        case 'In-Progress':
            $newStatus = 'Submitted';
            break;
        case 'Missing':
            $newStatus = 'Late';
            break;
        case 'Revision':
            $newStatus = 'Revised';
            break;
        default:
            $newStatus = $currentStatus;
    }

    // Update the task with the proof and new status
    $query = "UPDATE tasks SET proof = ?, proof_filename = ?, status = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('bssi', $null, $proofFilename, $newStatus, $taskId);

    // Send the LONGBLOB data separately
    $stmt->send_long_data(0, $proof);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $stmt->error]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}
?>
