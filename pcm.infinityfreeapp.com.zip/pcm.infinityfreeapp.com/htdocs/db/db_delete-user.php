<?php
include 'db_connection.php';

// Get the JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Check if the ID is set
if (isset($input['id'])) {
    $userId = $input['id'];

    // Prepare the SQL statement to delete the user
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);

    // Execute the statement and check for errors
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $stmt->error]);
    }

    // Close the statement
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid ID']);
}

// Close the database connection
$conn->close();
?>