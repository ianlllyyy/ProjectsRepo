<?php
include 'db_connection.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php'; // Load PHPMailer

$taskName = $_POST['taskName'];
$taskDescription = $_POST['taskDescription'];
$assignedTo = $_POST['assignTo'];
$dueTime = $_POST['dueTime'];
$status = 'Pending';
$attachment = null;
$attachmentFilename = null;

if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] == UPLOAD_ERR_OK) {
    $attachment = file_get_contents($_FILES['attachment']['tmp_name']);
    $attachmentFilename = $_FILES['attachment']['name'];
}

date_default_timezone_set('Asia/Singapore'); // GMT+8
$startTime = date('Y-m-d H:i:s');

// Fetch the email of the assigned user
$userQuery = "SELECT email FROM users WHERE id = ?";
$userStmt = $conn->prepare($userQuery);
$userStmt->bind_param('i', $assignedTo);
$userStmt->execute();
$userResult = $userStmt->get_result();
$userEmail = null;

if ($userResult->num_rows > 0) {
    $userEmail = $userResult->fetch_assoc()['email'];
}
$userStmt->close();

$query = "INSERT INTO tasks (taskname, taskdescription, starttime, duetime, assignedto, status, attachment, attachment_filename) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param('ssssisss', $taskName, $taskDescription, $startTime, $dueTime, $assignedTo, $status, $attachment, $attachmentFilename);

$response = ['success' => false];

if ($stmt->execute()) {
    $response['success'] = true;

    // Send email notification using PHPMailer
    if ($userEmail) {
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = 'smtp-relay.brevo.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = '881e6f001@smtp-brevo.com';
            $mail->Password   = 'DUdcLHzJTvW8pFVZ';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;

            $mail->setFrom('klydel0219@gmail.com', 'PCM Task Planner');
            $mail->addAddress($userEmail);

            $mail->Subject = 'New Task Assigned';
            $mail->Body    = "Hello,\n\nYou have been assigned a new task:\n\n" .
                             "Task Name: $taskName\n" .
                             "Description: $taskDescription\n" .
                             "Start Time: $startTime\n" .
                             "Due Time: $dueTime\n\n" .
                             "Please log in to the Task Planner system to view more details.\n\n" .
                             "Best regards,\nTask Planner Team";

            $mail->send();
            $response['email_sent'] = true;
        } catch (Exception $e) {
            $response['email_sent'] = false;
            $response['error'] = "Error sending email: " . $mail->ErrorInfo;
        }
    }
}

$stmt->close();
$conn->close();

echo json_encode($response);
?>