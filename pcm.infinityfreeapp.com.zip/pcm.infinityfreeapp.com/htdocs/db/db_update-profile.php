<?php
include 'db_connection.php';

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the user ID from the POST request
    $id = $_POST['id'];

    // Get the form data
    $fullname = $_POST['fullname'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $university = $_POST['school'];

    // Check if username or email is already taken (excluding the current user)
    $checkQuery = "SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("ssi", $username, $email, $id);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Username or email is already in use
        echo json_encode(['success' => false, 'message' => 'Username or Email is already taken.']);
        exit;
    }
    $stmt->close();

    // Handle profile image upload
    if (isset($_FILES['profile_img']) && $_FILES['profile_img']['error'] === UPLOAD_ERR_OK) {
        $profile_img = file_get_contents($_FILES['profile_img']['tmp_name']);
        $query = "UPDATE users SET fullname = ?, username = ?, email = ?, pfp = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssssi", $fullname, $username, $email, $profile_img, $id);
    } else {
        $query = "UPDATE users SET fullname = ?, username = ?, email = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssi", $fullname, $username, $email, $id);
    }

    if ($stmt->execute()) {
        $response = ['success' => true];
    } else {
        $response = ['success' => false, 'message' => 'Failed to update profile.'];
    }

    $stmt->close();
    $conn->close();

    // Return the JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>