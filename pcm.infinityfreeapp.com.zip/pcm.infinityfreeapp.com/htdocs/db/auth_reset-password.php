<?php 
include 'db_connection.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php'; // LOAD PHPMAILER

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'] ?? '';

    if (empty($email)) {
        echo "Email is required";
        exit;
    }

    // CHECK IF EMAIL EXISTS
    $checkEmailQuery = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($checkEmailQuery);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo "No account found with that email.";
        exit();
    }

    // GENERATE TEMP PASSWORD
    $tempPassword = substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*"), 0, 10);
    $hashedPassword = password_hash($tempPassword, PASSWORD_DEFAULT);

    // UPDATE THE PASSWORD ON DB TO THE NEW TEMPORARY PASSWORD
    $sql = "UPDATE users SET password = ? WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $hashedPassword, $email);
    
    if ($stmt->execute()) {
        // SEND EMAIL
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = 'smtp-relay.brevo.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = '881e6f001@smtp-brevo.com';
            $mail->Password   = 'DUdcLHzJTvW8pFVZ';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;

            $mail->setFrom('klydel0219@gmail.com', 'PCM Task Planner');
            $mail->addAddress($email);

            $mail->Subject = 'Password Reset Request';
            $mail->Body    = "Hello, \n\nYour new temporary password is: $tempPassword\n\nPlease log in and change your password immediately.";

            $mail->send();
            echo "Success";
        } catch (Exception $e) {
            echo "Error sending email: " . $mail->ErrorInfo;
        }
    } else {
        echo "Error updating password: " . $conn->error;
    }

    $stmt->close();
}
$conn->close();
?>
