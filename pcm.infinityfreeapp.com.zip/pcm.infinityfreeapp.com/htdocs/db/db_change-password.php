<?php
include 'db_connection.php';

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the user ID from the POST request
    $id = $_POST['id'];
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_new_password = $_POST['confirm_new_password'];

    // Fetch the current password from the database
    $query = "SELECT password FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($hashed_password);
    $stmt->fetch();
    $stmt->close();

    // Verify the current password
    if (password_verify($current_password, $hashed_password)) {
        // Check if the new password and confirm new password match
        if ($new_password === $confirm_new_password) {
            // Hash the new password
            $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            // Update the password in the database
            $query = "UPDATE users SET password = ? WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("si", $new_hashed_password, $id);

            if ($stmt->execute()) {
                $response = ['success' => true];
            } else {
                $response = ['success' => false, 'message' => 'Failed to update password.'];
            }

            $stmt->close();
        } else {
            $response = ['success' => false, 'message' => 'New password and confirm new password do not match.'];
        }
    } else {
        $response = ['success' => false, 'message' => 'Current password is incorrect.'];
    }

    $conn->close();

    // Return the JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>