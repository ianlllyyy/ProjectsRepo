<?php
header("Location: https://pcm.infinityfreeapp.com/auth_login.php");
exit();
?>