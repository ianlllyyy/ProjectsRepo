<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <!-- Styles -->
    <link rel="stylesheet" href="style/root.css">
    <link rel="stylesheet" href="style/component_sidebar.css">
    <link rel="stylesheet" href="style/acc_profile.css">
    <!-- Font awesome icon lib -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <?php
    $current_page = basename($_SERVER['PHP_SELF']);
    include 'components/user_sidebar.php';
    include 'db/db_connection.php';

    $query = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    $stmt->close();
    $conn->close();
    ?>

    <div class="main-content">
        <h1>Profile</h1>
        <p>Your profile, your productivity hub.</p>
        <div class="navbar">
            <a href="#" class="nav-link active" data-target="profile-settings">Profile Settings</a>
            <a href="#" class="nav-link" data-target="change-password">Change Password</a>
        </div>
        <div id="profile-settings" class="content-section active">
            <img src="data:image/jpeg;base64,<?php echo base64_encode($user['pfp']); ?>" alt="Profile Picture">
            <form id="profileForm" method="POST" enctype="multipart/form-data">

                <input type="hidden" name="id" value="<?php echo htmlspecialchars($user['id']); ?>">
                <input type="hidden" name="current_profile_img" value="<?php echo htmlspecialchars($user['pfp']); ?>">

                <div id="profile-img-wrapper">
                    <label>Upload Profile Picture</label>
                    <p>Maximum file size: 64MB</p>
                    <input type="file" name="profile_img" accept="image/*" disabled>
                </div>

                <label>Full Name</label>
                <input type="text" name="fullname" value="<?php echo htmlspecialchars($user['fullname']); ?>" required disabled>

                <label>Username</label>
                <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required disabled>

                <label>Email</label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required disabled>

                <label>University</label>
                <input type="text" name="school" value="<?php echo htmlspecialchars($user['university']); ?>" required disabled>

                <label for="department">Choose a Department:</label>
                <select id="department" name="department" id="department" disabled>
                    <option value="Marketing" <?php echo ($user['department'] === 'Marketing') ? 'selected' : ''; ?>>Marketing</option>
                    <option value="Admin" <?php echo ($user['department'] === 'Admin') ? 'selected' : ''; ?>>Admin</option>
                    <option value="IT" <?php echo ($user['department'] === 'IT') ? 'selected' : ''; ?>>IT</option>
                    <option value="HR" <?php echo ($user['department'] === 'HR') ? 'selected' : ''; ?>>HR</option>
                </select>

                <label>Position</label>
                <input id="position" type="text" name="position" value="<?php echo htmlspecialchars($user['position']); ?>" required disabled>

                <div class="modal-buttons">
                    <button type="button" id="editProfileButton">Edit Profile</button>
                    <button type="button" id="cancelButton" hidden>Cancel</button>
                    <button type="submit" id="saveChangesButton" hidden>Save Changes</button>
                </div>
            </form>
        </div>

        <div id="change-password" class="content-section">
            <h2>Change Password</h2>
            <form id="changePasswordForm" method="POST">

                <input type="hidden" name="id" value="<?php echo htmlspecialchars($user['id']); ?>">

                <label>Current Password</label>
                <div class="password-wrapper">
                    <input type="password" name="current_password" required id="current-password">
                    <span class="toggle-password" data-target="current-password">
                        <i class="fa-solid fa-eye-slash"></i>
                    </span>
                </div>

                <label>New Password</label>
                <div class="password-wrapper">
                    <input type="password" name="new_password" minlength="8" required id="new-password">
                    <span class="toggle-password" data-target="new-password">
                        <i class="fa-solid fa-eye-slash"></i>
                    </span>
                </div>

                <label>Confirm New Password</label>
                <div class="password-wrapper">
                    <input type="password" name="confirm_new_password" required id="confirm-password">
                    <span class="toggle-password" data-target="confirm-password">
                        <i class="fa-solid fa-eye-slash"></i>
                    </span>
                </div>

                <div class="modal-buttons">
                    <button type="submit">Change Password</button>
                </div>
            </form>
        </div>
    </div>
</body>
<script src="js/acc_profile.js"></script>

</html>