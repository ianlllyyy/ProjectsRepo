<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Intern List</title>
    <!-- Styles -->
    <link rel="stylesheet" href="style/root.css">
    <link rel="stylesheet" href="style/component_sidebar.css">
    <link rel="stylesheet" href="style/admin_userlist.css">
    <!-- Font awesome icon lib -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <?php
    $current_page = basename($_SERVER['PHP_SELF']);
    include 'components/admin_sidebar.php';

    include 'db/db_connection.php';

    $department_filter = isset($_GET['department']) ? $_GET['department'] : 'All';
    $university_filter = isset($_GET['university']) ? $_GET['university'] : 'All';
    $search_filter = isset($_GET['search']) ? $_GET['search'] : '';

    // Define the number of items per page
    $itemsPerPage = 10;

    $currentPage = isset($_GET['page']) ? (int) $_GET['page'] : 1;
    if ($currentPage < 1)
        $currentPage = 1;

    $offset = ($currentPage - 1) * $itemsPerPage;

    $internsQuery = "
        SELECT *
        FROM users
        WHERE position = 'Intern'
    ";

    if ($position !== 'Admin') {
        $internsQuery .= " AND department = '$department'";
    }

    if (!empty($search_filter)) {
        $internsQuery .= " AND fullname LIKE '%$search_filter%'";
    }

    if ($department_filter !== 'All') {
        $internsQuery .= " AND department = '$department_filter'";
    }

    if ($university_filter !== 'All') {
        $internsQuery .= " AND university = '$university_filter'";
    }

    $internsQuery .= " ORDER BY fullname ASC LIMIT $itemsPerPage OFFSET $offset";

    // Execute the query and check for errors
    $internsResult = $conn->query($internsQuery);
    if (!$internsResult) {
        die("Query failed: " . $conn->error);
    }

    // Get the total number of interns for pagination
    $countQuery = "
        SELECT COUNT(*) AS total
        FROM users
        WHERE position = 'Intern'
    ";

    if ($position !== 'Admin') {
        $countQuery .= " AND department = '$department'";
    }

    // Add search filter to count query
    if (!empty($search_filter)) {
        $countQuery .= " AND fullname LIKE '%$search_filter%'";
    }

    // Add department filter to count query
    if ($department_filter !== 'All') {
        $countQuery .= " AND department = '$department_filter'";
    }

    // Add university filter to count query
    if ($university_filter !== 'All') {
        $countQuery .= " AND university = '$university_filter'";
    }

    $countResult = $conn->query($countQuery);
    $totalItems = $countResult->fetch_assoc()['total'];
    $totalPages = ceil($totalItems / $itemsPerPage);
    ?>
    <div class="main-content">
        <h1>User List</h1>
        <p>View all interns.</p>
        <!-- FILTER CONTROLS -->
        <div class="filter-controls">
            <div class="left-section">
                <button id="refreshButton" onclick="window.location.href='?department=All&university=All&search='"><i
                        class="fa fa-refresh"></i></button>
                <div class="search-bar">
                    <i class="fa fa-search"></i>
                    <input type="text" id="searchInput" name="search" placeholder="Search intern name..."
                        value="<?php echo htmlspecialchars(isset($_GET['search']) ? $_GET['search'] : ''); ?>"
                        onkeypress="if(event.keyCode == 13) { window.location.href='?department=<?php echo isset($_GET['department']) ? $_GET['department'] : 'All'; ?>&university=<?php echo isset($_GET['university']) ? $_GET['university'] : 'All'; ?>&search=' + this.value; }">
                </div>
                <button id="searchButton"
                    onclick="window.location.href='?department=<?php echo isset($_GET['department']) ? $_GET['department'] : 'All'; ?>&university=<?php echo isset($_GET['university']) ? $_GET['university'] : 'All'; ?>&search=' + document.getElementById('searchInput').value">Search</button>
            </div>
            <div class="right-section">
                <!-- DEPARTMENT DROPDOWN -->
                <?php if ($position === 'Admin'): ?>
                    <div class="dropdown-wrapper">
                        <select id="departmentDropdownFilter" name="department"
                            onchange="window.location.href='?department=' + this.value + '&university=<?php echo isset($_GET['university']) ? $_GET['university'] : 'All'; ?>&search=<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>'">
                            <option value='All'>Select Department</option>
                            <option value="IT" <?php echo (isset($_GET['department']) && $_GET['department'] === 'IT') ? 'selected' : ''; ?>>IT</option>
                            <option value="HR" <?php echo (isset($_GET['department']) && $_GET['department'] === 'HR') ? 'selected' : ''; ?>>HR</option>
                            <option value="Admin" <?php echo (isset($_GET['department']) && $_GET['department'] === 'Admin') ? 'selected' : ''; ?>>Admin</option>
                            <option value="Marketing" <?php echo (isset($_GET['department']) && $_GET['department'] === 'Marketing') ? 'selected' : ''; ?>>Marketing</option>
                        </select>
                    </div>
                <?php endif; ?>
                <!-- UNIVERSITY DROPDOWN -->
                <div class="dropdown-wrapper">
                    <select id="universityDropdownFilter" name="university"
                        onchange="window.location.href='?department=<?php echo isset($_GET['department']) ? $_GET['department'] : 'All'; ?>&university=' + this.value + '&search=<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>'">
                        <option value='All'>Select University</option>
                        <?php
                        // Get unique universities from users table
                        $universityQuery = "SELECT DISTINCT university FROM users WHERE university IS NOT NULL AND university != '' ORDER BY university ASC";
                        $universityResult = $conn->query($universityQuery);
                        if ($universityResult && $universityResult->num_rows > 0) {
                            while ($row = $universityResult->fetch_assoc()) {
                                $university = $row['university'];
                                echo '<option value="' . htmlspecialchars($university) . '" ' . ((isset($_GET['university']) && $_GET['university'] === $university) ? 'selected' : '') . '>' . htmlspecialchars($university) . '</option>';
                            }
                        }
                        ?>
                    </select>
                </div>
                <!-- CREATE USER BUTTON -->
                <button id="createUserButton">
                    <i class="fa fa-plus"></i> Create User
                </button>
            </div>
        </div>

        <!-- INTERNS TABLE -->
        <div class="table-container">
            <?php if ($internsResult->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th></th>
                            <th>Full Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>University</th>
                            <?php if ($position === 'Admin'): ?>
                                <th>Department</th>
                            <?php endif; ?>
                            <th>Gender</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($intern = $internsResult->fetch_assoc()): ?>
                                <?php
                                $profile_img = base64_encode($intern['pfp']);
                                ?>
                                <td><img src="data:image/png;base64,<?php echo $profile_img; ?>"
                                        onclick="showProfileModal('<?php echo $profile_img; ?>')"></td>
                                <td><?php echo htmlspecialchars($intern['fullname']); ?></td>
                                <td><?php echo htmlspecialchars($intern['username']); ?></td>
                                <td><?php echo htmlspecialchars($intern['email']); ?></td>
                                <td><?php echo htmlspecialchars($intern['university']); ?></td>
                                <?php if ($position === 'Admin'): ?>
                                    <td><?php echo htmlspecialchars($intern['department']); ?></td>
                                <?php endif; ?>
                                <td><?php echo htmlspecialchars($intern['gender']); ?></td>
                                <td>
                                    <button class="action-btn deleteUserButton" data-id="<?= $intern['id'] ?>"><i
                                            class="fa fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <h2 class="no-data"><i class="fa-solid fa-folder-open"></i> No data found</h2>
            <?php endif; ?>
        </div>
        <!-- Pagination -->
        <?php if ($totalItems > $itemsPerPage): ?>
            <div class="pagination">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <a href="?page=<?= $i ?>" class="<?= ($i == $currentPage) ? 'active' : '' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>

        <!-- Create account modal -->
        <div id="createUserModal" class="modal-overlay">
            <div class="modal-container">
                <h2>Create an account</h2>
                <p>Enter the details below to create an account for a new user.</p>
                <form class="registerForm" id="registerForm">
                    <div class="name-wrapper">
                        <input type="text" name="firstname" placeholder="First Name" required>
                        <input type="text" name="middleinit" placeholder="Middle Initial">
                        <input type="text" name="lastname" placeholder="Last Name" required>
                    </div>
                    <input type="text" name="username" placeholder="Username" required>
                    <input type="email" name="email" placeholder="Email" required>
                    <select name="gender" required>
                        <option value="">Select Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                    <input type="text" name="university" placeholder="University" required>
                    <select name="department" required>
                        <option value="">Select Department</option>
                        <option value="Marketing">Marketing</option>
                        <option value="Admin">Admin</option>
                        <option value="IT">IT</option>
                        <option value="HR">HR</option>
                    </select>
                    <select name="position" required>
                        <option value="">Select Position</option>
                        <option value="Intern">Intern</option>
                        <option value="Supervisor">Supervisor</option>
                        <option value="Admin">Admin</option>
                    </select>
                    <div class="modal-buttons">
                        <button type="submit" name="register" id="register-btn">Create</button>
                        <button type="button" onclick="closeModal('createUserModal')">Close</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- View profile picture -->
        <div id="viewProfileModal" class="modal-overlay" onclick="closeModal('viewProfileModal')">
                <img id="profileModalImg" src="" alt="Profile Picture">
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Refresh button click event
            document.getElementById('refreshButton').addEventListener('click', () => {
                window.location.href = 'admin_userlist.php';
            });

            // Delete user button click event
            document.querySelectorAll('.deleteUserButton').forEach(button => {
                button.addEventListener('click', function() {
                    const userId = this.getAttribute('data-id');
                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            fetch('db/db_delete-user.php', {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json'
                                    },
                                    body: JSON.stringify({
                                        id: userId
                                    })
                                })
                                .then(response => response.json())
                                .then(data => {
                                    if (data.success) {
                                        Swal.fire({
                                            title: 'Deleted!',
                                            text: 'User has been deleted.',
                                            icon: 'success',
                                            confirmButtonText: 'OK'
                                        }).then(() => {
                                            window.location.reload();
                                        });
                                    } else {
                                        Swal.fire({
                                            title: 'Error!',
                                            text: data.error,
                                            icon: 'error',
                                            confirmButtonText: 'OK'
                                        });
                                    }
                                })
                                .catch(error => {
                                    console.error('Error:', error);
                                    Swal.fire({
                                        title: 'Error!',
                                        text: 'An error occurred while deleting user.',
                                        icon: 'error',
                                        confirmButtonText: 'OK'
                                    });
                                });
                        }
                    });
                });
            });

            document.getElementById('createUserButton').addEventListener('click', () => {
                document.getElementById('createUserModal').style.display = 'flex';
            });

            // Register account button clicked
            document.getElementById('registerForm').addEventListener('submit', function(e) {
                e.preventDefault();

                const formData = new FormData(this);

                Swal.fire({
                    title: 'Creating user...',
                    html: 'Please wait while the user is being created.',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                fetch('db/auth_register-account.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.text())
                    .then(result => {
                        if (result.trim() === "Account created successfully.") {
                            Swal.fire({
                                title: 'Success!',
                                text: result,
                                icon: 'success',
                                confirmButtonText: 'OK'
                            }).then(() => {
                                window.location.reload();
                            });
                        } else {
                            Swal.fire({
                                title: 'Error!',
                                text: result,
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire({
                            title: 'Error!',
                            text: 'An error occurred. Please try again.',
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    });
            });
        });

        // Function to show profile modal
        function showProfileModal(profileImg) {
            document.getElementById('profileModalImg').src = 'data:image/png;base64,' + profileImg;
            document.getElementById('viewProfileModal').style.display = 'flex';
        }

        // Function to close modal
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
    </script>
</body>

</html>