<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <!-- Styles -->
    <link rel="stylesheet" href="style/root.css">
    <link rel="stylesheet" href="style/component_sidebar.css">
    <link rel="stylesheet" href="style/user_tasklist.css">
    <!-- Font awesome icon lib -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
<?php
    $current_page = basename($_SERVER['PHP_SELF']);
    include 'components/user_sidebar.php';

    include 'db/db_connection.php';

    // Initialize search and status query
    $searchQuery = '';
    $statusQuery = '';
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $searchQuery = $_GET['search'];
    }
    if (isset($_GET['status']) && $_GET['status'] !== 'All') {
        $statusQuery = $_GET['status'];
    }

    // Set the number of tasks per page
    $tasks_per_page = 10;
    // Capture the current page number from the URL, default to 1 if not set
    $current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    // Calculate the offset for the query
    $offset = ($current_page - 1) * $tasks_per_page;

    // Fetch the total number of tasks assigned to the logged-in user where the status is not "Archived"
    $count_query = "SELECT COUNT(*) AS total FROM tasks WHERE assignedto = ? AND status != 'Archived'";
    if (!empty($searchQuery)) {
        $count_query .= " AND taskname LIKE ?";
    }
    if (!empty($statusQuery)) {
        $count_query .= " AND status = ?";
    }
    $count_stmt = $conn->prepare($count_query);
    if (!empty($searchQuery) && !empty($statusQuery)) {
        $searchParam = '%' . $searchQuery . '%';
        $count_stmt->bind_param('iss', $id, $searchParam, $statusQuery);
    } elseif (!empty($searchQuery)) {
        $searchParam = '%' . $searchQuery . '%';
        $count_stmt->bind_param('is', $id, $searchParam);
    } elseif (!empty($statusQuery)) {
        $count_stmt->bind_param('is', $id, $statusQuery);
    } else {
        $count_stmt->bind_param('i', $id);
    }
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $total_tasks = $count_result->fetch_assoc()['total'];

    // Fetch tasks assigned to the logged-in user where the status is not "Archived" with limit and offset
    $query = "SELECT * FROM tasks WHERE assignedto = ? AND status != 'Archived'";
    if (!empty($searchQuery)) {
        $query .= " AND taskname LIKE ?";
    }
    if (!empty($statusQuery)) {
        $query .= " AND status = ?";
    }
    $query .= " ORDER BY CASE WHEN status = 'Completed' THEN 1 ELSE 0 END, duetime ASC";
    $query .= " LIMIT ? OFFSET ?";
    $stmt = $conn->prepare($query);
    if (!empty($searchQuery) && !empty($statusQuery)) {
        $stmt->bind_param('issii', $id, $searchParam, $statusQuery, $tasks_per_page, $offset);
    } elseif (!empty($searchQuery)) {
        $stmt->bind_param('isii', $id, $searchParam, $tasks_per_page, $offset);
    } elseif (!empty($statusQuery)) {
        $stmt->bind_param('isii', $id, $statusQuery, $tasks_per_page, $offset);
    } else {
        $stmt->bind_param('iii', $id, $tasks_per_page, $offset);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    ?>
    <div class="main-content">
        <h1>My Tasks</h1>
        <p>"Stay organized and on track—here are your tasks for today!"</p>
        
        <!-- Filter controls -->
        <div class="filter-controls">
            <div class="left-section">
                <button id="refreshButton" onclick="window.location.href='user_tasklist.php'"><i class="fa fa-refresh"></i></button>
                <div class="search-bar">
                    <i class="fa fa-search"></i>
                    <input type="text" id="searchInput" name="search" placeholder="Search task name..." value="<?= htmlspecialchars($searchQuery) ?>">
                </div>
                <button id="searchButton">Search</button>
            </div>
            <div class="right-section">
                <div class="dropdown-wrapper">
                    <select id="statusDropdownFilter" name="status" onchange="window.location.href='?status=' + this.value + '&search=<?= htmlspecialchars($searchQuery) ?>'">
                        <option value="All" <?= $statusQuery === 'All' ? 'selected' : '' ?>>Select Status</option>
                        <option value="Pending" <?= $statusQuery === 'Pending' ? 'selected' : '' ?>>Pending</option>
                        <option value="In-Progress" <?= $statusQuery === 'In-Progress' ? 'selected' : '' ?>>In-Progress</option>
                        <option value="Missing" <?= $statusQuery === 'Missing' ? 'selected' : '' ?>>Missing</option>
                        <option value="Late" <?= $statusQuery === 'Late' ? 'selected' : '' ?>>Late</option>
                        <option value="Revision" <?= $statusQuery === 'Revision' ? 'selected' : '' ?>>Revision</option>
                        <option value="Revised" <?= $statusQuery === 'Revised' ? 'selected' : '' ?>>Revised</option>
                        <option value="Completed" <?= $statusQuery === 'Completed' ? 'selected' : '' ?>>Completed</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Display tasks in a table -->
        <div class="table-container">
            <?php if ($result->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Task</th>
                            <th>Given</th>
                            <th>Due</th>
                            <th>Status</th>
                            <th></th>
                            <th>Attachment</th>
                            <th>Proof</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($task = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($task['taskname']); ?></td>
                                <td><?php echo htmlspecialchars((new DateTime($task['starttime']))->format('g:i A, M. j, Y')); ?></td>
                                <td><?php echo htmlspecialchars((new DateTime($task['duetime']))->format('g:i A, M. j, Y')); ?></td>
                                <td>
                                    <!-- Custom status text -->
                                    <?php
                                    switch (strtolower($task['status'])) {
                                        case 'pending':
                                            echo '<span class="orange-text text">' . htmlspecialchars($task["status"]) . '</span>';
                                            break;
                                        case 'in-progress':
                                            echo '<span class="blue-text text">' . htmlspecialchars($task["status"]) . '</span>';
                                            break;
                                        case 'submitted':
                                            echo '<span class="green-text-v2 text">' . htmlspecialchars($task["status"]) . '</span>';
                                            break;
                                        case 'missing':
                                            echo '<span class="red-text text">' . htmlspecialchars($task["status"]) . '</span>';
                                            break;
                                        case 'late':
                                            echo '<span class="red-text-v2 text">' . htmlspecialchars($task["status"]) . '</span>';
                                            break;
                                        case 'revision':
                                            echo '<span class="orange-text-v2 text">' . htmlspecialchars($task["status"]) . '</span>';
                                            break;
                                        case 'revised':
                                            echo '<span class="blue-text-v2 text">' . htmlspecialchars($task["status"]) . '</span>';
                                            break;
                                        case 'completed':
                                            echo '<span class="green-text text">' . htmlspecialchars($task["status"]) . '</span>';
                                            break;
                                        default:
                                            echo '<span class="gray-text text">' . htmlspecialchars($task['status']) . '</span>';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php if ($task['status'] === 'Pending'): ?>
                                        <button class="acceptTaskButton" data-id="<?php echo $task['id']; ?>">
                                            <i class="fa fa-check"></i>Accept
                                        </button>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?= !empty($task['attachment']) ? '<a href="db/db_view-taskfile.php?id=' . $task['id'] . '&type=attachment" target="_blank" class="blue-text text"><i class="fa-solid fa-paperclip"></i> ' . (strlen($task['attachment_filename']) > 12 ? substr($task['attachment_filename'], 0, 12) . '...' : $task['attachment_filename']) . '</a>' : '<span class="gray-text text"><i class="fa-solid fa-xmark"></i> No Attachment</span>'; ?>
                                </td>
                                <td>
                                    <?php if (!empty($task['proof']) && $task['status'] !== 'Completed'): ?>
                                        <button class="cancelSubmitButton" data-id="<?= $task['id'] ?>">
                                            <i class="fa-solid fa-xmark"></i>
                                        </button>
                                    <?php endif; ?>
                                    <?= !empty($task['proof']) ? '<a href="db/db_view-taskfile.php?id=' . $task['id'] . '&type=proof" target="_blank" class="blue-text text"><i class="fa-solid fa-paperclip"></i> ' . (strlen($task['proof_filename']) > 12 ? substr($task['proof_filename'], 0, 12) . '...' : $task['proof_filename']) . '</a>' : '<span class="gray-text text"><i class="fa-solid fa-xmark"></i> No Proof</span>'; ?>
                                </td>
                                <td>
                                    <button class="viewTaskButton" data-id="<?= $task['id'] ?>">
                                        <i class="fa-solid fa-circle-info"></i>
                                    </button>
                                    <?php if ($task['status'] !== 'Pending' && $task['status'] !== 'Completed'): ?>
                                        <button class="submitProofButton" data-id="<?= $task['id'] ?>">
                                            <i class="fa fa-paper-plane"></i>
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <!-- Display a message if no tasks are found -->
            <?php else: ?>
                <h2 class="no-data"><i class="fa-solid fa-folder-open"></i> No data found</h2>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <?php if ($total_tasks > $tasks_per_page): ?>
            <div class="pagination">
                <?php for ($page = 1; $page <= ceil($total_tasks / $tasks_per_page); $page++): ?>
                    <a href="?page=<?= $page ?>&search=<?= htmlspecialchars($searchQuery) ?>" class="<?= $page == $current_page ? 'active' : '' ?>"><?= $page ?></a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Task details modal -->
    <div id="detailsModal" class="modal-overlay">
        <div class="modal-container task-details">
            <h2 id="taskTitle">Task Details</h2>
            <p>Given: <span id="task_Start">Jun. 19, 2003 | 10:30 AM</span></p>
            <div class="task-info">
                <p>Due: <strong><span id="task_End">Jun. 19, 2003 | 10:30 AM</span></strong></p>
                <p>Status: <span id="task_Status" class="text orange-text">Pending</span></p>
                <p>Attachment: <span id="task_File"></span></p>
            </div>
            <div class="task-content">
                <h3>Description</h3>
                <p id="task_Description">None</p>
            </div>
            <div class="task-comment">
                <h3>Comments</h3>
                <p id="task_Comments">None</p>
            </div>
            <div class="modal-buttons">
                <button onclick="closeModalDetails('detailsModal')">Close</button>
            </div>
        </div>
    </div>

    <!-- Submit proof modal -->
    <div id="submitProofModal" class="modal-overlay">
        <div class="modal-container">
            <h1>Submit Task</h1>
            <p>Submit Proof of you Task Here:</p>
            <form id="submitProofForm" enctype="multipart/form-data">
                <div class="task-info">
                    <input type="hidden" id="taskID" name="taskID">
                    <input type="file" id="proofSubmit" name="proofSubmit" 
                        accept="image/*,.pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,
                        .mp4,.mov,.avi,.wmv,.flv,.mkv,
                        .zip,.rar,.7z,
                        .psd,.ai,.indd">
                </div>
                <div class="modal-buttons">
                    <button type="submit" id="submitBtn" class="submit-btn">Submit</button>
                    <button type="button" onclick="closeModalDetails('submitProofModal')">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script src="js/user_tasklist.js"></script>
</body>

</html>