<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- Styles -->
    <link rel="stylesheet" href="style/root.css">
    <link rel="stylesheet" href="style/component_sidebar.css">
    <link rel="stylesheet" href="style/admin_reports.css">
    <!-- Font awesome icon lib -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>

    <?php
    $current_page = basename($_SERVER['PHP_SELF']);
    include 'components/admin_sidebar.php';
    ?>

    <div class="main-content">
        <h1>Reports</h1>
        <p>Oversee each intern's task. You may assign a task to an intern, or to all of them.</p>

        <!-- Filter controls -->
        <div class="filter-controls">
            <div class="left-section">
                <button id="refreshButton" onclick="window.location.href='?status=All&university=All&search='"><i
                        class="fa fa-refresh"></i></button>
                <div class="search-bar">
                    <i class="fa fa-search"></i>
                    <input type="text" id="searchInput" name="search" placeholder="Search task name..."
                        value="<?php echo htmlspecialchars(isset($_GET['search']) ? $_GET['search'] : ''); ?>"
                        onkeypress="if(event.keyCode == 13) { window.location.href='?status=<?php echo isset($_GET['status']) ? $_GET['status'] : 'All'; ?>&university=<?php echo isset($_GET['university']) ? $_GET['university'] : 'All'; ?>&search=' + this.value; }">
                </div>
                <button id="searchButton"
                    onclick="window.location.href='?status=<?php echo isset($_GET['status']) ? $_GET['status'] : 'All'; ?>&university=<?php echo isset($_GET['university']) ? $_GET['university'] : 'All'; ?>&search=' + document.getElementById('searchInput').value">Search</button>
            </div>
            <div class="right-section">
                <div class="dropdown-wrapper">
                    <select id="statusDropdownFilter" name="status"
                        onchange="window.location.href='?status=' + this.value + '&university=<?php echo isset($_GET['university']) ? $_GET['university'] : 'All'; ?>&search=<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>'">
                        <option value="All" <?php echo (isset($_GET['status']) && $_GET['status'] === 'All') ? 'selected' : ''; ?>>Select Status</option>
                        <option value="Pending" <?php echo (isset($_GET['status']) && $_GET['status'] === 'Pending') ? 'selected' : ''; ?>>Pending</option>
                        <option value="In-Progress" <?php echo (isset($_GET['status']) && $_GET['status'] === 'In-Progress') ? 'selected' : ''; ?>>In-Progress</option>
                        <option value="Missing" <?php echo (isset($_GET['status']) && $_GET['status'] === 'Missing') ? 'selected' : ''; ?>>Missing</option>
                        <option value="Late" <?php echo (isset($_GET['status']) && $_GET['status'] === 'Late') ? 'selected' : ''; ?>>Late</option>
                        <option value="Revision" <?php echo (isset($_GET['status']) && $_GET['status'] === 'Revision') ? 'selected' : ''; ?>>Revision</option>
                        <option value="Revised" <?php echo (isset($_GET['status']) && $_GET['status'] === 'Revised') ? 'selected' : ''; ?>>Revised</option>
                        <option value="Completed" <?php echo (isset($_GET['status']) && $_GET['status'] === 'Completed') ? 'selected' : ''; ?>>Completed</option>
                    </select>
                </div>
                <div class="dropdown-wrapper">
                    <select id="schoolDropdownFilter" name="university"
                        onchange="window.location.href='?status=<?php echo isset($_GET['status']) ? $_GET['status'] : 'All'; ?>&university=' + this.value + '&search=<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>'">
                        <option value="All" <?php echo (isset($_GET['university']) && $_GET['university'] === 'All') ? 'selected' : ''; ?>>Select University</option>

                        <?php
                        include 'db/db_connection.php';
                        $universityQuery = "SELECT DISTINCT university FROM users WHERE university IS NOT NULL AND university != '' ORDER BY university ASC";
                        $universityResult = $conn->query($universityQuery);
                        if ($universityResult && $universityResult->num_rows > 0) {
                            while ($row = $universityResult->fetch_assoc()) {
                                $university = $row['university'];
                                echo '<option value="' . htmlspecialchars($university) . '" ' . ((isset($_GET['university']) && $_GET['university'] === $university) ? 'selected' : '') . '>' . htmlspecialchars($university) . '</option>';
                            }
                        }
                        ?>

                    </select>
                </div>
                <!-- Assign task button -->
                <button id="assignTaskButton">
                    <i class="fa fa-plus"></i> Assign Task
                </button>
            </div>
        </div>

        <!-- To populate table -->
        <?php
        include 'db/db_connection.php';

        $status_filter = isset($_GET['status']) ? $_GET['status'] : 'All';
        $university_filter = isset($_GET['university']) ? $_GET['university'] : 'All';
        $search_filter = isset($_GET['search']) ? $_GET['search'] : '';

        // Get total number of tasks (excluding archived ones) base on position
        if ($position === 'Admin') {
            $countQuery = "SELECT COUNT(*) AS total FROM tasks";
            if ($university_filter !== 'All') {
                $countQuery .= " JOIN users ON tasks.assignedto = users.id";
            }
            $countQuery .= " WHERE tasks.status != 'Archived'";
        } else {
            $countQuery = "SELECT COUNT(*) AS total FROM tasks JOIN users ON tasks.assignedto = users.id WHERE tasks.status != 'Archived' AND users.department = '$department'";
        }

        if ($status_filter !== 'All') {
            $countQuery .= " AND tasks.status = '$status_filter'";
        }

        if ($university_filter !== 'All') {
            $countQuery .= " AND users.university = '$university_filter'";
        }

        if (!empty($search_filter)) {
            $countQuery .= " AND tasks.taskname LIKE '%$search_filter%'";
        }

        $countResult = $conn->query($countQuery);
        if (!$countResult) {
            die("Query failed: " . $conn->error);
        }

        $row = $countResult->fetch_assoc();
        $totalTasks = $row['total'];

        // Define items per page
        $itemsPerPage = 10;
        $totalPages = ceil($totalTasks / $itemsPerPage);

        $currentPage = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($currentPage < 1)
            $currentPage = 1;
        if ($currentPage > $totalPages)
            $currentPage = $totalPages;
        $offset = max(0, ($currentPage - 1) * $itemsPerPage);

        $tasksQuery = "
            SELECT tasks.*, users.pfp, users.fullname AS assignedto
            FROM tasks
            LEFT JOIN users ON tasks.assignedto = users.id
            WHERE tasks.status != 'Archived'
        ";

        if ($position !== 'Admin') {
            $tasksQuery .= " AND users.department = '$department'";
        }

        if ($status_filter !== 'All') {
            $tasksQuery .= " AND tasks.status = '$status_filter'";
        }

        if ($university_filter !== 'All') {
            $tasksQuery .= " AND users.university = '$university_filter'";
        }

        if (!empty($search_filter)) {
            $tasksQuery .= " AND tasks.taskname LIKE '%$search_filter%'";
        }

        $tasksQuery .= " ORDER BY tasks.duetime ASC";

        $tasksQuery .= " LIMIT $itemsPerPage OFFSET $offset";
        $tasksResult = $conn->query($tasksQuery);
        ?>

        <!-- Task table -->
        <div class="table-container">
            <?php if ($tasksResult->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th></th>
                            <th>Task</th>
                            <th>Assigned To</th>
                            <th style="width: 200px;">Given</th>
                            <th style="width: 200px;">Due</th>
                            <th style="width: 150px;">Status</th>
                            <th style="width: 200px;">Attachment</th>
                            <th style="width: 150px;">Proof</th>
                            <th style="width: 150px;"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($task = $tasksResult->fetch_assoc()): ?>
                            <tr>
                                <?php
                                $profile_img = base64_encode($task['pfp']);
                                ?>
                                <td><img src="data:image/png;base64,<?php echo $profile_img; ?>"
                                        onclick="showProfileModal('<?php echo $profile_img; ?>')"></td>
                                <td><?php echo htmlspecialchars($task['taskname']); ?></td>
                                <td><?php echo htmlspecialchars($task['assignedto']); ?></td>
                                <td><?php echo htmlspecialchars((new DateTime($task['starttime']))->format('g:i A, M. j, Y')); ?>
                                </td>
                                <td><?php echo htmlspecialchars((new DateTime($task['duetime']))->format('g:i A, M. j, Y')); ?>
                                </td>
                                <td>
                                    <!-- Custom status text -->
                                    <?php
                                    switch (strtolower($task['status'])) {
                                        case 'pending':
                                            echo '<span class="orange-text text">' . htmlspecialchars($task["status"]) . '</span>';
                                            break;
                                        case 'in-progress':
                                            echo '<span class="blue-text text">' . htmlspecialchars($task["status"]) . '</span>';
                                            break;
                                        case 'submitted':
                                            echo '<span class="green-text-v2 text">' . htmlspecialchars($task["status"]) . '</span>';
                                            break;
                                        case 'missing':
                                            echo '<span class="red-text text">' . htmlspecialchars($task["status"]) . '</span>';
                                            break;
                                        case 'late':
                                            echo '<span class="red-text-v2 text">' . htmlspecialchars($task["status"]) . '</span>';
                                            break;
                                        case 'revision':
                                            echo '<span class="orange-text-v2 text">' . htmlspecialchars($task["status"]) . '</span>';
                                            break;
                                        case 'revised':
                                            echo '<span class="blue-text-v2 text">' . htmlspecialchars($task["status"]) . '</span>';
                                            break;
                                        case 'completed':
                                            echo '<span class="green-text text">' . htmlspecialchars($task["status"]) . '</span>';
                                            break;
                                        default:
                                            echo '<span class="gray-text text">' . htmlspecialchars($task['status']) . '</span>';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php if (!empty($task['attachment']) && $task['status'] !== 'Completed'): ?>
                                        <button class="deleteAttachmentButton" data-id="<?= $task['id'] ?>">
                                            <i class="fa-solid fa-xmark"></i>
                                        </button>
                                    <?php endif; ?>
                                    <?= !empty($task['attachment']) ? '<a href="db/db_view-taskfile.php?id=' . $task['id'] . '&type=attachment" target="_blank" class="blue-text text"><i class="fa-solid fa-paperclip"></i> Attachment</a>' : '<span class="gray-text text"><i class="fa-solid fa-xmark"></i> No Attachment</span>'; ?>
                                </td>
                                <td>
                                    <?= !empty($task['proof']) ? '<a href="db/db_view-taskfile.php?id=' . $task['id'] . '&type=proof" target="_blank" class="blue-text text"><i class="fa-solid fa-paperclip"></i> Proof</a>' : '<span class="gray-text text"><i class="fa-solid fa-xmark"></i> No Proof</span>'; ?>
                                </td>
                                <td>
                                    <button class="viewTaskButton" data-id="<?= $task['id'] ?>">
                                        <i class="fa-solid fa-circle-info"></i>
                                    </button>
                                    <button class="commentTaskButton" data-id="<?= $task['id'] ?>">
                                        <i class="fa fa-comment"></i>
                                    </button>
                                    <?php if ($task['status'] !== 'Completed'): ?>
                                    <button class="editTaskButton" data-id="<?= $task['id'] ?>">
                                        <i class="fa fa-pencil"></i>
                                    </button>
                                    <?php endif; ?>
                                    <?php if ($task['status'] === 'Completed'): ?>
                                        <button class="archiveTaskButton" data-id="<?= $task['id'] ?>">
                                            <i class="fa fa-folder-open"></i>
                                        </button>
                                    <?php endif; ?>
                                    <button class="deleteTaskButton" data-id="<?= $task['id'] ?>">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                    <?php if (!empty($task['proof']) && $task['status'] !== 'Completed'): ?>
                                        <button class="completeTaskButton" data-id="<?= $task['id'] ?>">
                                            <i class="fa fa-check"></i>
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <h2 class="no-data"><i class="fa-solid fa-folder-open"></i> No data found</h2>
            <?php endif; ?>
        </div>

        <!-- Pagenation -->
        <?php if ($totalTasks > $itemsPerPage): ?>
            <div class="pagination">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <a href="?page=<?= $i ?>&status=<?= $status_filter ?>&university=<?= $university_filter ?>&search=<?= $search_filter ?>"
                        class="<?= ($i == $currentPage) ? 'active' : '' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>

        <!-- ASSIGN TASK MODAL -->
        <div id="assignTaskModal" class="modal-overlay">
            <div class="modal-container">
                <h2>Create New Task</h2>
                <form id="assignTaskForm" enctype="multipart/form-data">
                    <div class="main">
                        <div class="left-container">
                            <label for="taskName">Task Name</label>
                            <input type="text" id="taskName" name="taskName" required>
                            <label for="taskDescription">Task Description</label>
                            <textarea id="taskDescription" name="taskDescription" required></textarea>
                            <label for="assignTo">Assign To</label>
                            <select id="assignTo" name="assignTo" required>
                                <option>Select Intern</option>
                                <?php
                                include 'db/db_connection.php';
                                $internQuery = "SELECT id, fullname FROM users WHERE position = 'Intern'";
                                if ($position === 'Supervisor') {
                                    $internQuery .= " AND department = '$department'";
                                }
                                $internQuery .= " ORDER BY fullname ASC";
                                $internResult = $conn->query($internQuery);
                                if ($internResult && $internResult->num_rows > 0) {
                                    while ($intern = $internResult->fetch_assoc()) {
                                        echo '<option value="' . htmlspecialchars($intern['id']) . '">' . htmlspecialchars($intern['fullname']) . '</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <div class="right-container">
                            <label for="dueTime">Due</label>
                            <div class="radio-buttons">
                                <div>
                                    <input type="radio" id="nextDay" name="dueTimeOption" value="nextDay" required>
                                    <label for="nextDay">Tomorrow</label>
                                </div>
                                <div>
                                    <input type="radio" id="nextWeek" name="dueTimeOption" value="nextWeek">
                                    <label for="nextWeek">Next Week</label>
                                </div>
                                <div>
                                    <input type="radio" id="custom" name="dueTimeOption" value="custom">
                                    <label for="custom">Custom</label>
                                </div>
                            </div>
                            <div id="customDateTimeContainer" style="display: none;">
                                <label for="customDueTime">Custom Due Time</label>
                                <input type="datetime-local" id="customDueTime" name="customDueTime">
                            </div>
                            <label for="editAttachment">Attachment</label>
                            <input type="file" id="editAttachment" name="attachment"
                                    accept="image/*,.pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,
                                        .mp4,.mov,.avi,.wmv,.flv,.mkv,
                                        .zip,.rar,.7z,
                                        .psd,.ai,.indd">
                        </div>
                    </div>
                    <div class="modal-buttons">
                        <button type="submit" id="assignBtn" class="assign-btn">Assign</button>
                        <button type="button" onclick="closeModalDetails('assignTaskModal')">Cancel</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Task details modal -->
        <div id="detailsModal" class="modal-overlay">
            <div class="modal-container task-details">
                <h2 id="taskTitle">Task Details</h2>
                <p>Given: <span id="task_Start">Jun. 19, 2003 | 10:30 AM</span></p>
                <div class="task-info">
                    <p>Due: <strong><span id="task_End">Jun. 19, 2003 | 10:30 AM</span></strong></p>
                    <p>Status: <span id="task_Status" class="text orange-text">Pending</span></p>
                    <p>Assigned To: <span id="task_AssignedTo">John Doe</span></p>
                    <p>Attachment: <span id="task_File"></span></p>
                </div>
                <div class="task-content">
                    <h3>Description</h3>
                    <p id="task_Description">None</p>
                </div>
                <div class="task-comment">
                    <h3>Comments</h3>
                    <p id="task_Comments">None</p>
                </div>
                <p>Submission: <span id="proof_File"></span></p>
                <div class="modal-buttons">
                    <button onclick="closeModalDetails('detailsModal')">Close</button>
                </div>
            </div>
        </div>

        <!-- Comment modal -->
        <div id="commentsModal" class="modal-overlay">
            <div class="modal-container">
                <h2>Add a comment</h2>
                <form id="commentForm">
                    <textarea id="taskComment" name="taskComment"></textarea>
                    <div class="modal-buttons">
                        <button type="submit" id="commentBtn">Update</button>
                        <button type="button" onclick="closeModalDetails('commentsModal')">Cancel</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- EDIT TASK MODAL -->
        <div id="editTaskModal" class="modal-overlay">
            <div class="modal-container">
                <h2>Create New Task</h2>
                <form id="editTaskForm" enctype="multipart/form-data">
                    <div class="main">
                        <div class="left-container">
                            <label for="taskName">Task Name</label>
                            <input type="text" id="taskName2" name="taskName" required>
                            <label for="taskDescription">Task Description</label>
                            <textarea id="taskDescription2" name="taskDescription" required></textarea>
                            <label for="assignTo">Assign To</label>
                            <select id="assignTo2" name="assignTo" required>
                                <?php
                                include 'db/db_connection.php';
                                $internQuery = "SELECT id, fullname FROM users WHERE position = 'Intern'";
                                if ($position === 'Supervisor') {
                                    $internQuery .= " AND department = '$department'";
                                }
                                $internQuery .= " ORDER BY fullname ASC";
                                $internResult = $conn->query($internQuery);
                                if ($internResult && $internResult->num_rows > 0) {
                                    while ($intern = $internResult->fetch_assoc()) {
                                        echo '<option value="' . htmlspecialchars($intern['id']) . '">' . htmlspecialchars($intern['fullname']) . '</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <div class="right-container">
                            <label for="dueTime">Due</label>
                            <input type="datetime-local" id="dueTime" name="dueTime" required>
                            <label for="editAttachment">Attachment</label>
                            <input type="file" id="editAttachment2" name="attachment"
                                accept="image/*,.pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,
                                        .mp4,.mov,.avi,.wmv,.flv,.mkv,
                                        .zip,.rar,.7z,
                                        .psd,.ai,.indd">
                        </div>
                    </div>
                    <div class="modal-buttons">
                        <button type="submit" id="editBtn" class="assign-btn">Edit Task</button>
                        <button type="button" onclick="closeModalDetails('editTaskModal')">Cancel</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- VIEW PROFILE MODAL -->
        <div id="viewProfileModal" class="modal-overlay" onclick="closeModalDetails('viewProfileModal')">
            <img id="profileModalImg" src="" alt="Profile Picture">
        </div>

    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Pop up assign task modal
            document.getElementById('assignTaskButton').addEventListener('click', function () {
                document.getElementById('assignTaskModal').style.display = 'flex';
            });

            // Show custom date-time input if custom option is selected
            document.querySelectorAll('input[name="dueTimeOption"]').forEach(radio => {
                radio.addEventListener('change', function () {
                    if (this.value === 'custom') {
                        document.getElementById('customDateTimeContainer').style.display = 'block';
                    } else {
                        document.getElementById('customDateTimeContainer').style.display = 'none';
                    }
                });
            });

            // Assign task (submit button clicked)
            document.getElementById('assignTaskForm').addEventListener('submit', function (event) {
                event.preventDefault();

                const formData = new FormData(this);
                const dueTimeOption = document.querySelector('input[name="dueTimeOption"]:checked').value;
                const currentDateTime = new Date();
                let dueTime;

                if (dueTimeOption === 'nextDay') {
                    const tomorrow = new Date(currentDateTime);
                    tomorrow.setUTCDate(tomorrow.getUTCDate() + 1);
                    tomorrow.setUTCHours(17, 0, 0, 0); // Set time to 5PM GMT
                    dueTime = tomorrow.toISOString().slice(0, 16);
                } else if (dueTimeOption === 'nextWeek') {
                    const nextMonday = new Date(currentDateTime);
                    nextMonday.setUTCDate(nextMonday.getUTCDate() + (8 - nextMonday.getUTCDay()) % 7);
                    nextMonday.setUTCHours(17, 0, 0, 0); // Set time to 5PM GMT
                    dueTime = nextMonday.toISOString().slice(0, 16);
                } else if (dueTimeOption === 'custom') {
                    dueTime = document.getElementById('customDueTime').value;
                    const selectedDueTime = new Date(dueTime);
                    if (selectedDueTime <= currentDateTime || (selectedDueTime - currentDateTime) < 3600000) {
                        alert('Custom due time must be in the future and at least 1 hour from now.');
                        return;
                    }
                }

                formData.append('dueTime', dueTime);

                Swal.fire({
                    title: 'Assigning Task...',
                    html: 'Please wait while the task is being assigned.',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                fetch('db/db_assign-task.php', {
                    method: 'POST',
                    body: formData
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                title: 'Task Assigned',
                                text: 'The task has been successfully assigned.',
                                icon: 'success'
                            }).then(() => {
                                window.location.reload();
                            });
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: 'An error occurred while assigning the task.',
                                icon: 'error'
                            });
                        }
                    })
                    .catch(error => console.error('Error:', error));
            });

            // Delete attachment button
            document.querySelectorAll('.deleteAttachmentButton').forEach(button => {
                button.addEventListener('click', function () {
                    const taskId = this.dataset.id;
                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            fetch('db/db_remove-attachment.php', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({ taskID: taskId })
                            })
                                .then(response => response.json())
                                .then(data => {
                                    if (data.success) {
                                        Swal.fire(
                                            'Deleted!',
                                            'The attachment has been deleted.',
                                            'success'
                                        ).then(() => {
                                            window.location.reload();
                                        });
                                    } else {
                                        Swal.fire(
                                            'Error!',
                                            'An error occurred while deleting the attachment.',
                                            'error'
                                        );
                                    }
                                })
                                .catch(error => {
                                    Swal.fire(
                                        'Error!',
                                        'An error occurred while deleting the attachment.',
                                        'error'
                                    );
                                });
                        }
                    });
                });
            });

            // View task button clicked
            document.querySelectorAll('.viewTaskButton').forEach(button => {
                button.addEventListener('click', function () {
                    let taskId = this.getAttribute('data-id');
                    fetch('db/db_view-task.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: 'task_id=' + taskId
                    })
                        .then(response => response.json())
                        .then(data => {
                            if (data.error) {
                                alert('Task not found');
                            } else {
                                document.getElementById('taskTitle').textContent = data.taskname;
                                document.getElementById('task_Description').textContent = data.taskdescription;
                                document.getElementById('task_Start').textContent = data.starttime;

                                const startTime = new Date(data.starttime).toLocaleString('en-US', {
                                    hour: 'numeric',
                                    minute: 'numeric',
                                    hour12: true,
                                    month: 'short',
                                    day: 'numeric',
                                    year: 'numeric'
                                });
                                const dueTime = new Date(data.duetime).toLocaleString('en-US', {
                                    hour: 'numeric',
                                    minute: 'numeric',
                                    hour12: true,
                                    month: 'short',
                                    day: 'numeric',
                                    year: 'numeric'
                                });

                                document.getElementById('task_Start').textContent = startTime;
                                document.getElementById('task_End').textContent = dueTime;

                                document.getElementById('task_Status').textContent = data.status;

                                document.getElementById('task_Status').classList.remove('orange-text', 'blue-text', 'green-text-v2', 'red-text', 'red-text-v2', 'orange-text-v2', 'blue-text-v2', 'green-text', 'gray-text');

                                switch (data.status) {
                                    case 'Pending':
                                        document.getElementById('task_Status').classList.add('orange-text');
                                        break;
                                    case 'In-Progress':
                                        document.getElementById('task_Status').classList.add('blue-text');
                                        break;
                                    case 'Submitted':
                                        document.getElementById('task_Status').classList.add('green-text-v2');
                                        break;
                                    case 'Missing':
                                        document.getElementById('task_Status').classList.add('red-text');
                                        break;
                                    case 'Late':
                                        document.getElementById('task_Status').classList.add('red-text-v2');
                                        break;
                                    case 'Revision':
                                        document.getElementById('task_Status').classList.add('orange-text-v2');
                                        break;
                                    case 'Revised':
                                        document.getElementById('task_Status').classList.add('blue-text-v2');
                                        break;
                                    case 'Completed':
                                        document.getElementById('task_Status').classList.add('green-text');
                                        break;
                                    default:
                                        document.getElementById('task_Status').classList.add('gray-text');
                                }

                                document.getElementById('task_AssignedTo').textContent = data.assigned_to;

                                const taskFileElement = document.getElementById('task_File');
                                if (data.attachment) {
                                    const attachmentFilename = data.attachment_filename.length > 12 ? data.attachment_filename.substring(0, 12) + '...' : data.attachment_filename;
                                    taskFileElement.innerHTML = `<a href="db/db_view-taskfile.php?id=${taskId}&type=attachment" target="_blank" class="blue-text text"><i class="fa-solid fa-paperclip"></i> ${attachmentFilename}</a>`;
                                } else {
                                    taskFileElement.innerHTML = '<span class="gray-text text"><i class="fa-solid fa-xmark"></i> No Attachment</span>';
                                }

                                const proofFileElement = document.getElementById('proof_File');
                                if (data.proof) {
                                    const proofFilename = data.proof_filename.length > 12 ? data.proof_filename.substring(0, 12) + '...' : data.proof_filename;
                                    proofFileElement.innerHTML = `<a href="db/db_view-taskfile.php?id=${taskId}&type=proof" target="_blank" class="blue-text text"><i class="fa-solid fa-paperclip"></i> ${proofFilename}</a>`;
                                } else {
                                    proofFileElement.innerHTML = '<span class="gray-text text"><i class="fa-solid fa-xmark"></i> No Proof</span>';
                                }

                                document.getElementById('task_Comments').textContent = data.comments ? data.comments : 'None';
                                document.getElementById('detailsModal').style.display = 'flex';
                            }
                        })
                        .catch(error => console.error('Error:', error));
                });
            });

            // Comment task button clicked
            document.querySelectorAll('.commentTaskButton').forEach(button => {
                button.addEventListener('click', function () {
                    let taskId = this.getAttribute('data-id');
                    fetch('db/db_view-task.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: 'task_id=' + taskId
                    })
                        .then(response => response.text())
                        .then(text => {
                            try {
                                const data = JSON.parse(text);
                                if (data.error) {
                                    alert('Task not found');
                                } else {
                                    document.getElementById('taskComment').value = data.comments ? data.comments : '';
                                    document.getElementById('commentsModal').style.display = 'flex';
                                    document.getElementById('commentForm').setAttribute('data-task-id', taskId);
                                }
                            } catch (error) {
                                console.error('Error parsing JSON:', error);
                            }
                        })
                        .catch(error => console.error('Error:', error));
                });
            });

            // Update comment (submit button clicked)
            document.getElementById('commentForm').addEventListener('submit', function (event) {
                event.preventDefault();

                const taskId = this.getAttribute('data-task-id');
                const comment = document.getElementById('taskComment').value;

                fetch('db/db_update-comment.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: 'task_id=' + taskId + '&comment=' + encodeURIComponent(comment)
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                title: 'Comment Updated',
                                text: 'The comment has been successfully updated.',
                                icon: 'success'
                            }).then(() => {
                                document.getElementById('commentsModal').style.display = 'none';
                                window.location.reload();
                            });
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: 'An error occurred while updating the comment.',
                                icon: 'error'
                            });
                        }
                    })
                    .catch(error => console.error('Error:', error));
            });

            // Edit task button clicked
            document.querySelectorAll('.editTaskButton').forEach(button => {
                button.addEventListener('click', function () {
                    let taskId = this.getAttribute('data-id');
                    fetch('db/db_view-task.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: 'task_id=' + taskId
                    })
                        .then(response => response.text())
                        .then(text => {
                            try {
                                const data = JSON.parse(text);
                                if (data.error) {
                                    alert('Task not found');
                                } else {
                                    document.getElementById('taskName2').value = data.taskname;
                                    document.getElementById('taskDescription2').value = data.taskdescription;
                                    document.getElementById('assignTo2').value = data.assignedto;
                                    document.getElementById('dueTime').value = data.duetime;

                                    document.getElementById('editTaskModal').style.display = 'flex';
                                    document.getElementById('editTaskForm').setAttribute('data-task-id', taskId);
                                }
                            } catch (error) {
                                console.error('Error parsing JSON:', error);
                            }
                        })
                        .catch(error => console.error('Error:', error));
                });
            });

            // Update task details (submit button clicked)
            document.getElementById('editTaskForm').addEventListener('submit', function (event) {
                event.preventDefault();

                const taskId = this.getAttribute('data-task-id');
                const formData = new FormData(this);
                formData.append('task_id', taskId);

                fetch('db/db_update-task.php', {
                    method: 'POST',
                    body: formData
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                title: 'Task Updated',
                                text: 'The task has been successfully updated.',
                                icon: 'success'
                            }).then(() => {
                                window.location.reload();
                            });
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: 'An error occurred while updating the task.',
                                icon: 'error'
                            });
                        }
                    })
                    .catch(error => console.error('Error:', error));
            });

            // Archive task
            document.querySelectorAll('.archiveTaskButton').forEach(button => {
                button.addEventListener('click', function () {
                    const taskId = this.getAttribute('data-id');
                    Swal.fire({
                        title: 'Archive Task?',
                        text: 'Are you sure you want to archive this task?',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Yes',
                        cancelButtonText: 'No'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            fetch('db/db_change-task-status.php', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/x-www-form-urlencoded'
                                },
                                body: 'id=' + taskId + '&action=archive'
                            })
                                .then(response => response.json())
                                .then(data => {
                                    if (data.success) {
                                        Swal.fire({
                                            title: 'Task Archived',
                                            text: 'The task has been archived',
                                            icon: 'success'
                                        }).then(() => {
                                            window.location.reload();
                                        });
                                    } else {
                                        Swal.fire({
                                            title: 'Error',
                                            text: 'An error occurred while archiving the task',
                                            icon: 'error'
                                        });
                                    }
                                })
                                .catch(error => console.error('Error:', error));
                        }
                    });
                });
            });

            // Delete task
            document.querySelectorAll('.deleteTaskButton').forEach(button => {
                button.addEventListener('click', function () {
                    const taskId = this.getAttribute('data-id');
                    Swal.fire({
                        title: 'Delete Task?',
                        text: 'Are you sure you want to delete this task?',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Yes',
                        cancelButtonText: 'No'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            fetch('db/db_change-task-status.php', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/x-www-form-urlencoded'
                                },
                                body: 'id=' + taskId + '&action=delete'
                            })
                                .then(response => response.json())
                                .then(data => {
                                    if (data.success) {
                                        Swal.fire({
                                            title: 'Task Deleted',
                                            text: 'The task has been deleted',
                                            icon: 'success'
                                        }).then(() => {
                                            window.location.reload();
                                        });
                                    } else {
                                        Swal.fire({
                                            title: 'Error',
                                            text: 'An error occurred while deleting the task',
                                            icon: 'error'
                                        });
                                    }
                                })
                                .catch(error => console.error('Error:', error));
                        }
                    });
                });
            });

            // Mark complete task
            document.querySelectorAll('.completeTaskButton').forEach(button => {
                button.addEventListener('click', function () {
                    const taskId = this.getAttribute('data-id');
                    Swal.fire({
                        title: 'Mark Task as Completed?',
                        text: 'Are you sure you want to mark this task as completed?',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Yes',
                        cancelButtonText: 'No'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            fetch('db/db_change-task-status.php', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/x-www-form-urlencoded'
                                },
                                body: 'id=' + taskId + '&action=complete'
                            })
                                .then(response => response.json())
                                .then(data => {
                                    if (data.success) {
                                        Swal.fire({
                                            title: 'Task Completed',
                                            text: 'The task has been marked as completed',
                                            icon: 'success'
                                        }).then(() => {
                                            window.location.reload();
                                        });
                                    } else {
                                        Swal.fire({
                                            title: 'Error',
                                            text: 'An error occurred while marking the task as completed',
                                            icon: 'error'
                                        });
                                    }
                                })
                                .catch(error => console.error('Error:', error));
                        }
                    });
                });
            });

        });

        // Function to close modal
        function closeModalDetails(modalId) {
            document.getElementById(modalId).style.display = 'none';
            document.getElementById('assignTaskForm').reset();
            document.getElementById('customDateTimeContainer').style.display = 'none';
        }

        // Function to show profile modal
        function showProfileModal(profileImg) {
            document.getElementById('profileModalImg').src = 'data:image/png;base64,' + profileImg;
            document.getElementById('viewProfileModal').style.display = 'flex';
        }
    </script>
</body>

</html>