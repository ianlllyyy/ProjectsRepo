<?php
session_start();

// Check if user is logged in - if not, redirect to login page
if (!isset($_SESSION['id'])) {
    header("Location: auth_login.php");
    exit();
}

include 'db/db_connection.php';

$id = $_SESSION['id']; // Session Variable

// Get user's details through session id
$query = "SELECT fullname, username, department,  position, pfp FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
if ($stmt === false) {
    die("Database error: " . $conn->error);
}
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

// Store user's details in variables to display in sidebar and some pages
$fullname = htmlspecialchars($row['fullname']);
$username = htmlspecialchars($row['username']);
$department = htmlspecialchars($row['department']);
$position = htmlspecialchars($row['position']);
$profile_img = base64_encode($row['pfp']);

$stmt->close();
$conn->close();

// If an admin/supervisor stumbles to this page - redirect to admin/supervisor's page
if ($position != "Intern") {
    header("Location: admin_dashboard.php");
    exit();
}
?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- Sweet alert lib -->
<!-- Sidebar layout -->
<div class="sidebar">
    <div class="logo">
        <img src="img/sidebar_logo.jpg">
        <h1>Task<span>Planner</span></h1>
    </div>
    <nav>
        <ul>
            <li><a href="user_dashboard.php" class="<?php echo $current_page == 'user_dashboard.php' ? 'active' : ''; ?>">
                <i class="fa-solid fa-table-columns"></i> Dashboard</a>
            </li>
            <li><a href="user_tasklist.php" class="<?php echo $current_page == 'user_tasklist.php' ? 'active' : ''; ?>">
                <i class="fa-solid fa-tasks"></i>Your Tasks</a>
            </li>
            <li><a href="user_profile.php" class="<?php echo $current_page == 'user_profile.php' ? 'active' : ''; ?>">
                <i class="fa-solid fa-user"></i>User Profile</a>
            </li>
        </ul>
    </nav>
    <div class="profile-box">
        <div class="profile-info">
            <img src="data:image/png;base64,<?php echo $profile_img; ?>">
            <div>
                <h3><?php echo $username; ?></h3>
                <small><?php echo $position; ?></small>
            </div>
        </div>
        <button id="logout-btn">Logout</button>
    </div>
</div>
<script src="js/acc_logout.js"></script> <!-- Logout script -->