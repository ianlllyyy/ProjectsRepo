<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- Styles -->
    <link rel="stylesheet" href="style/root.css">
    <link rel="stylesheet" href="style/auth_pages.css">
    <!-- Font awesome icon lib -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <div class="logo-container">
        <img src="img/login_fragranza-logo.png">
        <img src="img/login_pcm-logo.png">
    </div>
    <div class="register-modal">
        <div class="register-box">
            <h2>Create Account</h2>
            <p>Fill in your details below.</p>
            <form class="register-form" id="registerForm">
                <div class="name-wrapper">
                    <input type="text" name="firstname" placeholder="Firstname*" required>
                    <input type="text" name="lastname" placeholder="Lastname*" required>
                    <input type="text" name="middleinit" placeholder="M.I." maxlength="1">
                </div>
                <input type="text" name="username" placeholder="Username*" required>
                <input type="email" name="email" placeholder="Email*" required>
                <select name="gender" required>
                    <option value="">Select Gender*</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other/Prefer no to say</option>
                </select>
                <input list="university-list" name="university" placeholder="University*" required>
                <datalist id="university-list">
                    <?php
                    include 'db/db_connection.php';
                    $universityQuery = "SELECT DISTINCT university FROM users WHERE university IS NOT NULL AND university != '' ORDER BY university ASC";
                    $universityResult = $conn->query($universityQuery);

                    if ($universityResult && $universityResult->num_rows > 0) {
                        while ($row = $universityResult->fetch_assoc()) {
                            echo '<option value="' . htmlspecialchars($row['university']) . '"></option>';
                        }
                    }
                    ?>
                </datalist>
                <select name="department" required>
                    <option value="">Select Department*</option>
                    <option value="Marketing">Marketing</option>
                    <option value="Admin">Admin</option>
                    <option value="IT">IT</option>
                    <option value="HR">HR</option>
                </select>
                <div class="password-wrapper">
                    <input type="password" name="password" placeholder="Password*" minlength="8" required id="register-password">
                    <span class="toggle-password" data-target="register-password">
                        <i class="fa-solid fa-eye-slash"></i>
                    </span>
                </div>
                <div class="password-wrapper">
                    <input type="password" name="confirm_password" placeholder="Confirm Password*" required id="confirm-password">
                    <span class="toggle-password" data-target="confirm-password">
                        <i class="fa-solid fa-eye-slash"></i>
                    </span>
                </div>
                <button type="submit" name="register" id="register-btn">CREATE ACCOUNT</button>
            </form>
            <div class="login-options">
                <a href="auth_login.php" class="login-link">Already have an account?</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- Sweet alert lib -->
    <script>
        // Toggle password visibility
        document.querySelectorAll('.toggle-password').forEach(toggle => {
            toggle.addEventListener('click', function() {
                var targetInput = document.getElementById(this.getAttribute('data-target'));
                var icon = this.querySelector('i');

                if (targetInput.type === 'password') {
                    targetInput.type = 'text';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                } else {
                    targetInput.type = 'password';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                }
            });
        });

        document.getElementById('registerForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const password = document.getElementById('register-password').value;
            const confirmPassword = document.getElementById('confirm-password').value;

            if (password !== confirmPassword) {
                Swal.fire({
                    title: 'Error!',
                    text: 'Passwords do not match.',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
                return;
            }

            let timerInterval;
            Swal.fire({
                title: "Creating Account<span id='dots'>.</span>",
                html: "Setting up your account. Please wait...",
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                    const dots = document.getElementById('dots');
                    let count = 0;
                    timerInterval = setInterval(() => {
                        count = (count + 1) % 4;
                        dots.textContent = '.'.repeat(count);
                    }, 475);
                },
                willClose: () => {
                    clearInterval(timerInterval);
                }
            });

            setTimeout(() => {
                const formData = new FormData(this);
                fetch('db/auth_register-account.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.text())
                    .then(result => {
                        Swal.close();
                        if (result.trim() === "Account created successfully.") {
                            // Show success alert and wait for user confirmation
                            Swal.fire({
                                title: 'Success!',
                                text: 'Your account has been created successfully. Press OK to log in.',
                                icon: 'success',
                                confirmButtonText: 'OK'
                            }).then(() => {
                                // Automatically log in the user after confirmation
                                const loginData = new FormData();
                                loginData.append('username', formData.get('username'));
                                loginData.append('password', formData.get('password'));

                                fetch('db/auth_login.php', {
                                        method: 'POST',
                                        body: loginData
                                    })
                                    .then(loginResponse => loginResponse.text())
                                    .then(loginResult => {
                                        if (loginResult.trim() === "Intern Login successful.") {
                                            window.location.href = 'user_dashboard.php';
                                        } else if (loginResult.trim() === "Admin/Supervisor Login successful.") {
                                            window.location.href = 'admin_dashboard.php';
                                        } else {
                                            Swal.fire({
                                                title: 'Error!',
                                                text: loginResult,
                                                icon: 'error',
                                                confirmButtonText: 'OK'
                                            });
                                        }
                                    })
                                    .catch(error => {
                                        console.error('Error:', error);
                                        Swal.fire({
                                            title: 'Error!',
                                            text: 'An error occurred during login. Please try again.',
                                            icon: 'error',
                                            confirmButtonText: 'OK'
                                        });
                                    });
                            });
                        } else {
                            Swal.fire({
                                title: 'Error!',
                                text: result,
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    })
                    .catch(error => {
                        Swal.close();
                        console.error('Error:', error);
                        Swal.fire({
                            title: 'Error!',
                            text: 'An error occurred. Please try again.',
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    });
            }, 2000);
        });
    </script>
</body>

</html>