<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- Styles -->
    <link rel="stylesheet" href="style/root.css">
    <link rel="stylesheet" href="style/auth_pages.css">
    <!-- Font awesome icon lib -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <div class="logo-container">
        <img src="img/login_fragranza-logo.png">
        <img src="img/login_pcm-logo.png">
    </div>
    <div class="login-modal">
        <div class="login-box">
            <h2>Login</h2>
            <p>Enter your account details.</p>
            <form class="login-form" id="loginForm">
                <input type="text" name="username" placeholder="Username or Email" required>
                <div class="password-wrapper">
                    <input type="password" name="password" placeholder="Password" required id="login-password">
                    <span class="toggle-password" data-target="login-password">
                        <i class="fa-solid fa-eye-slash"></i>
                    </span>
                </div>
                <button type="submit" id="login-btn">LOGIN</button>
            </form>
            <div class="login-options">
                <a href="auth_forgot-pass.php" class="forgot-link">Forgot Password?</a>
                <span> | </span>
                <a href="auth_register.php" class="create-link">Create Account</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- Sweet alert lib -->
    <script>
        // Toggle password visibility
        document.querySelectorAll('.toggle-password').forEach(toggle => {
            toggle.addEventListener('click', function() {
                var targetInput = document.getElementById(this.getAttribute('data-target'));
                var icon = this.querySelector('i');

                if (targetInput.type === 'password') {
                    targetInput.type = 'text';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                } else {
                    targetInput.type = 'password';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                }
            });
        });

        // Login button clicked
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();

            Swal.fire({
                title: "Verifying<span id='dots'>.</span>",
                html: "Checking credentials. This won't take long.",
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                    const dots = document.getElementById('dots');
                    let count = 0;
                    setInterval(() => {
                        count = (count + 1) % 4;
                        dots.textContent = '.'.repeat(count);
                    }, 475);
                }
            });

            const formData = new FormData(this);
            fetch('db/auth_login.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.text())
                .then(result => {
                    setTimeout(() => {
                        Swal.close();
                        if (result.trim() === "Intern Login successful.") {
                            window.location.href = 'user_dashboard.php';
                        } else if (result.trim() === "Admin/Supervisor Login successful.") {
                            window.location.href = 'admin_dashboard.php';
                        } else {
                            Swal.fire({
                                title: 'Login failed',
                                text: result,
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    }, 4000);
                })
                .catch(error => {
                    Swal.close();
                    console.error('Error:', error);
                    Swal.fire({
                        title: 'Error!',
                        text: 'An error occurred. Please try again.',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                });
        });
    </script>
</body>

</html>