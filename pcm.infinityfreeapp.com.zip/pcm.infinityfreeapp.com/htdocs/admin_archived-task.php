<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archived Tasks</title>
    <!-- Styles -->
    <link rel="stylesheet" href="style/root.css">
    <link rel="stylesheet" href="style/component_sidebar.css">
    <link rel="stylesheet" href="style/admin_archived.css">
    <!-- Font awesome icon lib -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <?php
    $current_page = basename($_SERVER['PHP_SELF']);
    include 'components/admin_sidebar.php';

    include 'db/db_connection.php';

    $tasksQuery = "
        SELECT tasks.*, users.fullname AS assignedto
        FROM tasks
        JOIN users ON tasks.assignedto = users.id
        WHERE tasks.status = 'Archived'
    ";

    // If the logged-in user is a supervisor, add a condition to filter by department
    if ($position !== 'Admin') {
        $tasksQuery .= " AND users.department = '$department'";
    }

    $tasksQuery .= " ORDER BY tasks.duetime DESC";

    $tasksResult = $conn->query($tasksQuery);
    if (!$tasksResult) {
        die("Query failed: " . $conn->error);
    }
    ?>
    <div class="main-content">
        <h1>Archived Tasks</h1>
        <p>View all archived tasks.</p>
        <!-- Archived table -->
        <div class="table-container">
            <?php if ($tasksResult->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Task</th>
                            <th>Assigned To</th>
                            <th style="width: 200px;">Given</th>
                            <th style="width: 200px;">Due</th>
                            <th style="width: 150px;">Status</th>
                            <th style="width: 200px;">Attachment</th>
                            <th style="width: 150px;">Proof</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($task = $tasksResult->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($task['taskname']); ?></td>
                                <td><?php echo htmlspecialchars($task['assignedto']); ?></td>
                                <td><?php echo htmlspecialchars((new DateTime($task['starttime']))->format('g:i A, M. j, Y')); ?>
                                </td>
                                <td><?php echo htmlspecialchars((new DateTime($task['duetime']))->format('g:i A, M. j, Y')); ?>
                                </td>
                                <td>
                                    <span class="gray-text text"><?php echo htmlspecialchars($task['status']); ?></span>
                                </td>
                                <td>
                                    <?= !empty($task['attachment']) ? '<a href="db/db_view-taskfile.php?id=' . $task['id'] . '&type=attachment" target="_blank" class="blue-text text"><i class="fa-solid fa-paperclip"></i> Attachment</a>' : '<span class="gray-text text"><i class="fa-solid fa-xmark"></i> No Attachment</span>'; ?>
                                </td>
                                <td>
                                    <?= !empty($task['proof']) ? '<a href="db/db_view-taskfile.php?id=' . $task['id'] . '&type=proof" target="_blank" class="blue-text text"><i class="fa-solid fa-paperclip"></i> Proof</a>' : '<span class="gray-text text"><i class="fa-solid fa-xmark"></i> No Proof</span>'; ?>
                                </td>
                                <td>
                                    <button class="action-btn restoreTaskButton" data-id="<?= $task['id'] ?>">
                                        <i class="fa fa-refresh"></i>
                                    </button>
                                    <button class="action-btn deleteTaskButton" data-id="<?= $task['id'] ?>">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <h2 class="no-data"><i class="fa-solid fa-folder-open"></i> No data found</h2>
            <?php endif; ?>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Restore task button
            document.querySelectorAll('.restoreTaskButton').forEach(button => {
                button.addEventListener('click', function() {
                    const taskId = this.dataset.id;
                    Swal.fire({
                        title: 'Restore Task?',
                        text: 'Are you sure you want to restore this task status to Completed?',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Yes',
                        cancelButtonText: 'No'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            fetch('db/db_change-task-status.php', {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/x-www-form-urlencoded'
                                    },
                                    body: 'id=' + taskId + '&action=restore'
                                })
                                .then(response => response.json())
                                .then(data => {
                                    if (data.success) {
                                        Swal.fire({
                                            title: 'Task Refreshed',
                                            text: 'The task status has been restored',
                                            icon: 'success'
                                        }).then(() => {
                                            window.location.reload();
                                        });
                                    } else {
                                        Swal.fire({
                                            title: 'Error',
                                            text: data.message || 'An error occurred while refreshing the task status',
                                            icon: 'error'
                                        });
                                    }
                                })
                                .catch(error => console.error('Error:', error));
                        }
                    });
                });
            });

            // Delete Task
            document.querySelectorAll('.deleteTaskButton').forEach(button => {
                button.addEventListener('click', function() {
                    const taskId = this.getAttribute('data-id');
                    Swal.fire({
                        title: 'Delete Task?',
                        text: 'Are you sure you want to delete this task?',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Yes',
                        cancelButtonText: 'No'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            fetch('db/db_change-task-status.php', {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/x-www-form-urlencoded'
                                    },
                                    body: 'id=' + taskId + '&action=delete'
                                })
                                .then(response => response.json())
                                .then(data => {
                                    if (data.success) {
                                        Swal.fire({
                                            title: 'Task Deleted',
                                            text: 'The task has been deleted',
                                            icon: 'success'
                                        }).then(() => {
                                            window.location.reload();
                                        });
                                    } else {
                                        Swal.fire({
                                            title: 'Error',
                                            text: 'An error occurred while deleting the task',
                                            icon: 'error'
                                        });
                                    }
                                })
                                .catch(error => console.error('Error:', error));
                        }
                    });
                });
            });
        });
    </script>
</body>

</html>