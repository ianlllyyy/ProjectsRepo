<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Intern List</title>
    <!-- Styles -->
    <link rel="stylesheet" href="style/root.css">
    <link rel="stylesheet" href="style/component_sidebar.css">
    <link rel="stylesheet" href="style/admin_internlist.css">
    <!-- Font awesome icon lib -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <?php
    $current_page = basename($_SERVER['PHP_SELF']);
    include 'components/admin_sidebar.php'; // SIDEBAR COMPONENT
    
    include 'db/db_connection.php';

    $department_filter = isset($_GET['department']) ? $_GET['department'] : 'All';
    $university_filter = isset($_GET['university']) ? $_GET['university'] : 'All';
    $search_filter = isset($_GET['search']) ? $_GET['search'] : '';

    // Define the number of items per page
    $itemsPerPage = 10;

    $currentPage = isset($_GET['page']) ? (int) $_GET['page'] : 1;
    if ($currentPage < 1)
        $currentPage = 1;

    $offset = ($currentPage - 1) * $itemsPerPage;

    $internsQuery = "
            SELECT users.id, users.fullname, users.university, users.department, users.pfp, COUNT(tasks.id) AS task_count
            FROM users
            LEFT JOIN tasks ON users.id = tasks.assignedto
            WHERE users.position = 'Intern'
        ";

    if ($position !== 'Admin') {
        $internsQuery .= " AND department = '$department'";
    }

    if (!empty($search_filter)) {
        $internsQuery .= " AND users.fullname LIKE '%$search_filter%'";
    }

    if ($department_filter !== 'All') {
        $internsQuery .= " AND users.department = '$department_filter'";
    }

    if ($university_filter !== 'All') {
        $internsQuery .= " AND users.university = '$university_filter'";
    }

    $internsQuery .= " GROUP BY users.id, users.fullname, users.university, users.department
                   ORDER BY users.fullname ASC
                   LIMIT $itemsPerPage OFFSET $offset";

    $internsResult = $conn->query($internsQuery);

    if (!$internsResult) {
        die("Query failed: " . $conn->error);
    }

    $countQuery = "
        SELECT COUNT(*) AS total
        FROM users
        WHERE position = 'Intern'
    ";

    if ($position !== 'Admin') {
        $countQuery .= " AND department = '$department'";
    }

    if (!empty($search_filter)) {
        $countQuery .= " AND fullname LIKE '%$search_filter%'";
    }

    if ($department_filter !== 'All') {
        $countQuery .= " AND department = '$department_filter'";
    }

    if ($university_filter !== 'All') {
        $countQuery .= " AND university = '$university_filter'";
    }

    $countResult = $conn->query($countQuery);
    $totalItems = $countResult->fetch_assoc()['total'];
    $totalPages = ceil($totalItems / $itemsPerPage);
    ?>

    <div class="main-content">
        <h1>Intern List</h1>
        <p>View all interns and the number of tasks assigned to them.</p>

        <!-- Filter controls -->
        <div class="filter-controls">
            <div class="left-section">
                <button id="refreshButton" onclick="window.location.href='?department=All&university=All&search='"><i
                        class="fa fa-refresh"></i></button>
                <div class="search-bar">
                    <i class="fa fa-search"></i>
                    <input type="text" id="searchInput" name="search" placeholder="Search intern name..."
                        value="<?php echo htmlspecialchars(isset($_GET['search']) ? $_GET['search'] : ''); ?>"
                        onkeypress="if(event.keyCode == 13) { window.location.href='?department=<?php echo isset($_GET['department']) ? $_GET['department'] : 'All'; ?>&university=<?php echo isset($_GET['university']) ? $_GET['university'] : 'All'; ?>&search=' + this.value; }">
                </div>
                <button id="searchButton"
                    onclick="window.location.href='?department=<?php echo isset($_GET['department']) ? $_GET['department'] : 'All'; ?>&university=<?php echo isset($_GET['university']) ? $_GET['university'] : 'All'; ?>&search=' + document.getElementById('searchInput').value">Search</button>
            </div>
            <div class="right-section">
                <?php if ($position === 'Admin'): ?>
                    <div class="dropdown-wrapper">
                        <select id="departmentDropdownFilter" name="department"
                            onchange="window.location.href='?department=' + this.value + '&university=<?php echo isset($_GET['university']) ? $_GET['university'] : 'All'; ?>&search=<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>'">
                            <option value='All'>Select Department</option>
                            <option value="IT" <?php echo (isset($_GET['department']) && $_GET['department'] === 'IT') ? 'selected' : ''; ?>>IT</option>
                            <option value="HR" <?php echo (isset($_GET['department']) && $_GET['department'] === 'HR') ? 'selected' : ''; ?>>HR</option>
                            <option value="Admin" <?php echo (isset($_GET['department']) && $_GET['department'] === 'Admin') ? 'selected' : ''; ?>>Admin</option>
                            <option value="Marketing" <?php echo (isset($_GET['department']) && $_GET['department'] === 'Marketing') ? 'selected' : ''; ?>>Marketing</option>
                        </select>
                    </div>
                <?php endif; ?>
                <div class="dropdown-wrapper">
                    <select id="universityDropdownFilter" name="university"
                        onchange="window.location.href='?department=<?php echo isset($_GET['department']) ? $_GET['department'] : 'All'; ?>&university=' + this.value + '&search=<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>'">
                        <option value='All'>Select University</option>
                        <?php
                        // Get unique universities from users table
                        $universityQuery = "SELECT DISTINCT university FROM users WHERE university IS NOT NULL AND university != '' ORDER BY university ASC";
                        $universityResult = $conn->query($universityQuery);
                        if ($universityResult && $universityResult->num_rows > 0) {
                            while ($row = $universityResult->fetch_assoc()) {
                                $university = $row['university'];
                                echo '<option value="' . htmlspecialchars($university) . '" ' . ((isset($_GET['university']) && $_GET['university'] === $university) ? 'selected' : '') . '>' . htmlspecialchars($university) . '</option>';
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>
        </div>

        <!-- Intern table -->
        <div class="table-container">
            <?php if ($internsResult->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th></th>
                            <th>Intern</th>
                            <th>University</th>
                            <?php if ($position === 'Admin'): ?>
                                <th>Department</th>
                            <?php endif; ?>
                            <th>No. of Tasks</th>
                            <th style="width: 200px;">Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($intern = $internsResult->fetch_assoc()): ?>
                            <tr>
                                <?php
                                $profile_img = base64_encode($intern['pfp']);
                                ?>
                                <td><img src="data:image/png;base64,<?php echo $profile_img; ?>"
                                        onclick="showProfileModal('<?php echo $profile_img; ?>')"></td>
                                <td><?php echo htmlspecialchars($intern['fullname']); ?></td>
                                <td><?php echo htmlspecialchars($intern['university']); ?></td>
                                <?php if ($position === 'Admin'): ?>
                                    <td><?php echo htmlspecialchars($intern['department']); ?></td>
                                <?php endif; ?>
                                <td><?php echo htmlspecialchars($intern['task_count']); ?></td>
                                <td>
                                    <span class="<?= $intern['task_count'] > 0 ? 'text green-text' : 'text red-text' ?>">
                                        <?= $intern['task_count'] > 0 ? 'Task Assigned' : 'No tasks currently' ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="action-btn assignTaskButton" data-id="<?= $intern['id'] ?>"
                                        data-name="<?= htmlspecialchars($intern['fullname']) ?>">
                                        <i class="fa-solid fa-clipboard"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <h2 class="no-data"><i class="fa-solid fa-folder-open"></i> No data found</h2>
            <?php endif; ?>
        </div>
        <!-- Pagination -->
        <?php if ($totalItems > $itemsPerPage): ?>
            <div class="pagination">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <a href="?page=<?= $i ?>" class="<?= ($i == $currentPage) ? 'active' : '' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>

        <!-- Assign task modal -->
        <div id="assignTaskModal" class="modal-overlay">
            <div class="modal-container">
                <h2>Create New Task</h2>
                <form id="assignTaskForm" enctype="multipart/form-data">
                    <div class="main">
                        <div class="left-container">
                            <label for="taskName">Task Name</label>
                            <input type="text" id="taskName" name="taskName" required>
                            <label for="taskDescription">Task Description</label>
                            <textarea id="taskDescription" name="taskDescription" required></textarea>
                            <label for="assignTo">Assign To</label>
                            <select id="assignTo" name="assignTo" required>
                                <option>Select Intern</option>
                                <?php
                                include 'db/db_connection.php';
                                $internQuery = "SELECT id, fullname FROM users WHERE position = 'Intern'";
                                if ($position === 'Supervisor') {
                                    $internQuery .= " AND department = '$department'";
                                }
                                $internQuery .= " ORDER BY fullname ASC";
                                $internResult = $conn->query($internQuery);
                                if ($internResult && $internResult->num_rows > 0) {
                                    while ($intern = $internResult->fetch_assoc()) {
                                        echo '<option value="' . htmlspecialchars($intern['id']) . '">' . htmlspecialchars($intern['fullname']) . '</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <div class="right-container">
                            <label for="dueTime">Due</label>
                            <div class="radio-buttons">
                                <div>
                                    <input type="radio" id="nextDay" name="dueTimeOption" value="nextDay" required>
                                    <label for="nextDay">Tomorrow</label>
                                </div>
                                <div>
                                    <input type="radio" id="nextWeek" name="dueTimeOption" value="nextWeek">
                                    <label for="nextWeek">Next Week</label>
                                </div>
                                <div>
                                    <input type="radio" id="custom" name="dueTimeOption" value="custom">
                                    <label for="custom">Custom</label>
                                </div>
                            </div>
                            <div id="customDateTimeContainer" style="display: none;">
                                <label for="customDueTime">Custom Due Time</label>
                                <input type="datetime-local" id="customDueTime" name="customDueTime">
                            </div>
                            <label for="editAttachment">Attachment</label>
                            <input type="file" id="editAttachment" name="attachment"
                                accept="image/*,.pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,
                                        .mp4,.mov,.avi,.wmv,.flv,.mkv,
                                        .zip,.rar,.7z,
                                        .psd,.ai,.indd">
                        </div>
                    </div>
                    <div class="modal-buttons">
                        <button type="submit" id="assignBtn" class="assign-btn">Assign</button>
                        <button type="button" onclick="closeModalDetails('assignTaskModal')">Cancel</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- View profile modal -->
        <div id="viewProfileModal" class="modal-overlay" onclick="closeModalDetails('viewProfileModal')">
            <img id="profileModalImg" src="" alt="Profile Picture">
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Show assign task modal
            document.querySelectorAll('.assignTaskButton').forEach(button => {
                button.addEventListener('click', function () {
                    const internId = this.dataset.id;
                    const assignToSelect = document.getElementById('assignTo');

                    assignToSelect.value = internId;

                    document.getElementById('assignTaskModal').style.display = 'flex';
                });
            });

            // Show custom date-time input if custom option is selected
            document.querySelectorAll('input[name="dueTimeOption"]').forEach(radio => {
                radio.addEventListener('change', function () {
                    if (this.value === 'custom') {
                        document.getElementById('customDateTimeContainer').style.display = 'block';
                    } else {
                        document.getElementById('customDateTimeContainer').style.display = 'none';
                    }
                });
            });

            // Assign task (submit button clicked)
            document.getElementById('assignTaskForm').addEventListener('submit', function (event) {
                event.preventDefault();
                const assignToSelect = document.getElementById('assignTo');
                assignToSelect.disabled = false;

                const formData = new FormData(this);
                const dueTimeOption = document.querySelector('input[name="dueTimeOption"]:checked').value;
                const currentDateTime = new Date();
                let dueTime;

                    if (dueTimeOption === 'nextDay') {E
                        const tomorrow = new Date(currentDateTime);
                        tomorrow.setUTCDate(tomorrow.getUTCDate() + 1);
                        tomorrow.setUTCHours(17, 0, 0, 0); // Set time to 5PM GMT
                        dueTime = tomorrow.toISOString().slice(0, 16);
                    } else if (dueTimeOption === 'nextWeek') {
                        const nextMonday = new Date(currentDateTime);
                        nextMonday.setUTCDate(nextMonday.getUTCDate() + (8 - nextMonday.getUTCDay()) % 7);
                        nextMonday.setUTCHours(17, 0, 0, 0); // Set time to 5PM GMT
                        dueTime = nextMonday.toISOString().slice(0, 16);
                } else if (dueTimeOption === 'custom') {
                    dueTime = document.getElementById('customDueTime').value;
                    const selectedDueTime = new Date(dueTime);
                    if (selectedDueTime <= currentDateTime || (selectedDueTime - currentDateTime) < 3600000) {
                        alert('Custom due time must be in the future and at least 1 hour from now.');
                        return;
                    }
                }             

                formData.append('dueTime', dueTime);

                Swal.fire({
                    title: 'Assigning Task...',
                    html: 'Please wait while the task is being assigned.',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                fetch('db/db_assign-task.php', {
                    method: 'POST',
                    body: formData
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                title: 'Task Assigned',
                                text: 'The task has been successfully assigned.',
                                icon: 'success'
                            }).then(() => {
                                window.location.reload();
                            });
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: 'An error occurred while assigning the task.',
                                icon: 'error'
                            });
                        }
                    })
                    .catch(error => console.error('Error:', error));
            });
        });

        // Function to show profile modal
        function showProfileModal(profileImg) {
            document.getElementById('profileModalImg').src = 'data:image/png;base64,' + profileImg;
            document.getElementById('viewProfileModal').style.display = 'flex';
        }

        // Function to close modal
        function closeModalDetails(modalId) {
            document.getElementById(modalId).style.display = 'none';
            if (modalId === 'assignTaskModal') {
                document.getElementById('assignTaskForm').reset();
                document.getElementById('customDateTimeContainer').style.display = 'none';
            }
        }
    </script>

</body>

</html>