<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- Styles -->
    <link rel="stylesheet" href="style/root.css">
    <link rel="stylesheet" href="style/component_sidebar.css">
    <link rel="stylesheet" href="style/admin_dashboard.css">
    <!-- Font awesome icon lib -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <?php
    $current_page = basename($_SERVER['PHP_SELF']);
    include 'components/admin_sidebar.php';
    ?>

    <div class="main-content">
        <h1>Dashboard</h1>
        <p>Welcome <?php echo $fullname; ?>! Here's an overview of interns' progress.</p>

        <!-- Card displaying interns per department -->
        <div class="stats-card">

            <?php
            include 'db/db_connection.php';

            $internCounts = [
                'IT' => 0,
                'HR' => 0,
                'Marketing' => 0,
                'Admin' => 0
            ];

            $query = "
            SELECT 
                SUM(CASE WHEN department = 'IT' THEN 1 ELSE 0 END) AS IT,
                SUM(CASE WHEN department = 'HR' THEN 1 ELSE 0 END) AS HR,
                SUM(CASE WHEN department = 'Marketing' THEN 1 ELSE 0 END) AS Marketing,
                SUM(CASE WHEN department = 'Admin' THEN 1 ELSE 0 END) AS Admin
                FROM users
                WHERE position = 'Intern'
            ";

            $result = $conn->query($query);
            $internCounts = $result->fetch_assoc();

            $conn->close();
            ?>

            <!-- Admin sees all department cards -->
            <?php if ($position === "Admin"): ?>
                <div class="card">
                    <h3>IT Department</h3>
                    <h1><?php echo $internCounts['IT']; ?></h1>
                    <i class="fa-solid fa-computer"></i>
                </div>
                <div class="card">
                    <h3>Human Resource Department</h3>
                    <h1><?php echo $internCounts['HR']; ?></h1>
                    <i class="fa-solid fa-users"></i>
                </div>
                <div class="card">
                    <h3>Marketing Department</h3>
                    <h1><?php echo $internCounts['Marketing']; ?></h1>
                    <i class="fa-solid fa-user-tie"></i>
                </div>
                <div class="card">
                    <h3>Admin Department</h3>
                    <h1><?php echo $internCounts['Admin']; ?></h1>
                    <i class="fa-solid fa-briefcase"></i>
                </div>
            <!-- Supervisor sees only their department card -->
            <?php elseif ($position === "Supervisor"): ?>
                <?php if ($department === "IT"): ?>
                    <div class="card">
                        <h3>IT Department</h3>
                        <h1><?php echo $internCounts['IT']; ?></h1>
                        <i class="fa-solid fa-computer"></i>
                    </div>
                <?php elseif ($department === "HR"): ?>
                    <div class="card">
                        <h3>Human Resource Department</h3>
                        <h1><?php echo $internCounts['HR']; ?></h1>
                        <i class="fa-solid fa-users"></i>
                    </div>
                <?php elseif ($department === "Marketing"): ?>
                    <div class="card">
                        <h3>Marketing Department</h3>
                        <h1><?php echo $internCounts['Marketing']; ?></h1>
                        <i class="fa-solid fa-user-tie"></i>
                    </div>
                <?php elseif ($department === "Admin"): ?>
                    <div class="card">
                        <h3>Admin Department</h3>
                        <h1><?php echo $internCounts['Admin']; ?></h1>
                        <i class="fa-solid fa-briefcase"></i>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

    </div>
</body>