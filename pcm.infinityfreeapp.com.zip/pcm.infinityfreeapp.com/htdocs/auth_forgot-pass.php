<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- Styles -->
    <link rel="stylesheet" href="style/root.css">
    <link rel="stylesheet" href="style/auth_pages.css">
    <!-- Font awesome icon lib -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <div class="logo-container">
        <img src="img/login_fragranza-logo.png">
        <img src="img/login_pcm-logo.png">
    </div>
    <div class="forgot-password-modal">
        <div class="forgot-password-box">
            <h2>Forgot Password</h2>
            <p>Enter your registered email to reset your password.</p>
            <form class="forgot-password-form" id="forgotPasswordForm">
                <input type="email" name="email" placeholder="Email" required>
                <button type="submit" id="resetpasswordBtn">RESET PASSWORD</button>
                <span class="error-message" id="forgot-password-error"></span>
            </form>
            <div class="login-options">
                <a href="auth_login.php" class="login-link">Back to Login</a>
                <span> | </span>
                <a href="auth_register.php" class="create-link">Create Account</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- Sweet alert lib -->
    <script>
        // Reset password button clicked
        document.getElementById('forgotPasswordForm').addEventListener('submit', function(e) {
            e.preventDefault();
            document.getElementById('forgot-password-error').textContent = "";

            let timerInterval;
            Swal.fire({
                title: "Verifying your request<span id='dots'>.</span>",
                html: 'Hang tight! We are sending an email to reset your password.',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                    const dots = document.getElementById('dots');
                    let count = 0;
                    timerInterval = setInterval(() => {
                        count = (count + 1) % 4;
                        dots.textContent = ".".repeat(count);
                    }, 500);
                },
                willClose: () => {
                    clearInterval(timerInterval);
                }
            });

            // Send the form data via Fetch API and check response
            const formData = new FormData(this);
            fetch('db/auth_reset-password.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.text())
                .then(result => {
                    setTimeout(() => {
                        Swal.close();

                        if (result.trim() === "Success") {
                            Swal.fire({
                                title: 'Success!',
                                text: 'Email has been sent. Please check your inbox.',
                                icon: 'success',
                                confirmButtonText: 'Back to Login'
                            }).then(() => {
                                window.location.href = 'auth_login.php';
                            });
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: result,
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    }, 2000); // Delay of 2 seconds
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        title: 'Error',
                        text: 'An error occurred while processing your request. Please try again later.',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                });
        });
    </script>
</body>

</html>