document.getElementById("logout-btn").addEventListener("click", function () {
    // Logout confirmation
    Swal.fire({
        title: "Are you sure?",
        text: "You will be logged out!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6",
        confirmButtonText: "Yes, logout!"
    }).then((result) => {
        if (result.isConfirmed) {
            let timerInterval;
            // Artificial loading (4 seconds)
            Swal.fire({
                title: 'Logging out<span id="dots">.</span>',
                html: 'Please wait while we securely sign you out.',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                    const dots = document.getElementById('dots');
                    let count = 0;
                    timerInterval = setInterval(() => {
                        count = (count + 1) % 4;
                        dots.textContent = '.'.repeat(count);
                    }, 475);
                },
                willClose: () => {
                    clearInterval(timerInterval);
                }
            });
            // Logout
            setTimeout(() => {
                window.location.href = 'auth_logout.php';
            }, 4000);
        }
    });
});