document.addEventListener("DOMContentLoaded", function() {
    const navLinks = document.querySelectorAll(".nav-link");
    const contentSections = document.querySelectorAll(".content-section");
    // Switching between profile or change password
    navLinks.forEach(link => {
        link.addEventListener("click", function(event) {
            event.preventDefault();
            document.querySelector(".nav-link.active")?.classList.remove("active");
            this.classList.add("active");

            const target = this.getAttribute("data-target");
            contentSections.forEach(section => {
                if (section.id === target) {
                    section.style.display = 'flex';
                    if (target === 'change-password') {
                        addChangePasswordEventListener();
                    }
                } else {
                    section.style.display = 'none';
                }
            });
        });
    });

    // ID of all forms (for disable and enabling)
    const editProfileButton = document.getElementById('editProfileButton');
    const cancelButton = document.getElementById('cancelButton');
    const saveChangesButton = document.getElementById('saveChangesButton');
    const profileImgInput = document.getElementById('profile-img-wrapper');
    const formInputs = document.querySelectorAll('#profile-settings input, #profile-settings select');

    // Initially hide the profile picture upload input
    profileImgInput.style.display = 'none';

    // Edit profile button clicked
    editProfileButton.addEventListener('click', function() {
        formInputs.forEach(input => input.disabled = false);
        document.getElementById('department').disabled = document.getElementById('position').disabled = true;
        profileImgInput.style.display = 'flex';
        saveChangesButton.hidden = false;
        cancelButton.hidden = false;
        editProfileButton.hidden = true;
    });

    // Reload the page when "Cancel" is clicked
    cancelButton.addEventListener('click', function() {
        location.reload();
    });

    // Save changes button clicked (update profile)
    document.getElementById('profileForm').addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(this);

        fetch('db/db_update-profile.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Profile Updated',
                        text: 'Your profile has been updated successfully.',
                        confirmButtonText: 'OK'
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: data.message,
                        confirmButtonText: 'OK'
                    });
                }
            })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'An error occurred while updating your profile.',
                    confirmButtonText: 'OK'
                });
            });
    });

    // Change password button clicked
    function addChangePasswordEventListener() {
        document.getElementById('changePasswordForm').addEventListener('submit', function(event) {
            event.preventDefault();

            const formData = new FormData(this);

            fetch('db/db_change-password.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Password Changed',
                            text: 'Your password has been changed successfully.',
                            confirmButtonText: 'OK'
                        }).then(() => {
                            location.reload();
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: data.message,
                            confirmButtonText: 'OK'
                        });
                    }
                })
                .catch(error => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'An error occurred while changing your password.',
                        confirmButtonText: 'OK'
                    });
                });
        });
    }

    // Toggle password visibility
    document.querySelectorAll('.toggle-password').forEach(toggle => {
        toggle.addEventListener('click', function() {
            const targetId = this.getAttribute('data-target');
            const targetInput = document.getElementById(targetId);
            const icon = this.querySelector('i');

            if (targetInput.type === 'password') {
                targetInput.type = 'text';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            } else {
                targetInput.type = 'password';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            }
        });
    });
});