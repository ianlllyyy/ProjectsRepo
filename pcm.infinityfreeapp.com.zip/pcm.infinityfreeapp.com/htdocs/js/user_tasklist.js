document.addEventListener('DOMContentLoaded', function() {

    // Accept Task Button
    document.querySelectorAll('.acceptTaskButton').forEach(button => {
        button.addEventListener('click', function() {
            const taskId = this.getAttribute('data-id');
            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want to accept this task?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, accept it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch('db/db_change-task-status.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded'
                            },
                            body: 'id=' + taskId + '&action=in-progress'
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                Swal.fire(
                                    'Accepted!',
                                    'The task has been accepted.',
                                    'success'
                                ).then(() => {
                                    location.reload();
                                });
                            } else {
                                Swal.fire(
                                    'Failed!',
                                    'Failed to update task status: ' + data.error,
                                    'error'
                                );
                            }
                        })
                        .catch(error => {
                            Swal.fire(
                                'Error!',
                                'An error occurred: ' + error.message,
                                'error'
                            );
                        });
                }
            });
        });
    });

    // Submit Proof Button
    document.querySelectorAll('.submitProofButton').forEach(button => {
        button.addEventListener('click', function() {
            const taskId = this.getAttribute('data-id');
            document.getElementById('taskID').value = taskId;
            document.getElementById('submitProofModal').style.display = 'flex';
        });
    });

    // Handle Submit Proof Form Submission
    document.getElementById('submitProofForm').addEventListener('submit', function(event) {
        event.preventDefault();
        const formData = new FormData(this);

        fetch('db/db_submit-proof.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire('Success!', 'Proof submitted successfully.', 'success').then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire('Error!', 'Failed to submit proof: ' + data.error, 'error');
                }
            })
            .catch(error => {
                Swal.fire('Error!', 'An error occurred: ' + error.message, 'error');
            });
    });

    // Cancel Submit Button
    document.querySelectorAll('.cancelSubmitButton').forEach(button => {
        button.addEventListener('click', function() {
            const taskId = this.getAttribute('data-id');
            const status = this.closest('tr').querySelector('td:nth-child(4) span').textContent.trim();

            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want to cancel the proof submission?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, cancel it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch('db/db_cancel-submit.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded'
                            },
                            body: 'taskID=' + taskId + '&status=' + status
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                Swal.fire('Cancelled!', 'The proof submission has been cancelled.', 'success').then(() => {
                                    location.reload();
                                });
                            } else {
                                Swal.fire('Error!', 'Failed to cancel proof submission: ' + data.error, 'error');
                            }
                        })
                        .catch(error => {
                            Swal.fire('Error!', 'An error occurred: ' + error.message, 'error');
                        });
                }
            });
        });
    });
    
    // Fetch task to display
    document.querySelectorAll('.viewTaskButton').forEach(button => {
        button.addEventListener('click', function() {
            let taskId = this.getAttribute('data-id');
            fetch('db/db_view-task.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: 'task_id=' + taskId
                })
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        alert('Task not found');
                    } else {
                        document.getElementById('taskTitle').textContent = data.taskname;
                        document.getElementById('task_Description').textContent = data.taskdescription;
                        document.getElementById('task_Start').textContent = data.starttime;

                        const startTime = new Date(data.starttime).toLocaleString('en-US', {
                            hour: 'numeric',
                            minute: 'numeric',
                            hour12: true,
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric'
                        });
                        const dueTime = new Date(data.duetime).toLocaleString('en-US', {
                            hour: 'numeric',
                            minute: 'numeric',
                            hour12: true,
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric'
                        });

                        document.getElementById('task_Start').textContent = startTime;
                        document.getElementById('task_End').textContent = dueTime;

                        document.getElementById('task_Status').textContent = data.status;

                        document.getElementById('task_Status').classList.remove('orange-text', 'blue-text', 'green-text-v2', 'red-text', 'red-text-v2', 'orange-text-v2', 'blue-text-v2', 'green-text', 'gray-text');

                        switch (data.status) {
                            case 'Pending':
                                document.getElementById('task_Status').classList.add('orange-text');
                                break;
                            case 'In-Progress':
                                document.getElementById('task_Status').classList.add('blue-text');
                                break;
                            case 'Submitted':
                                document.getElementById('task_Status').classList.add('green-text-v2');
                                break;
                            case 'Missing':
                                document.getElementById('task_Status').classList.add('red-text');
                                break;
                            case 'Late':
                                document.getElementById('task_Status').classList.add('red-text-v2');
                                break;
                            case 'Revision':
                                document.getElementById('task_Status').classList.add('orange-text-v2');
                                break;
                            case 'Revised':
                                document.getElementById('task_Status').classList.add('blue-text-v2');
                                break;
                            case 'Completed':
                                document.getElementById('task_Status').classList.add('green-text');
                                break;
                            default:
                                document.getElementById('task_Status').classList.add('gray-text');
                        }

                        const taskFileElement = document.getElementById('task_File');
                        if (data.attachment) {
                            const attachmentFilename = data.attachment_filename.length > 12 ? data.attachment_filename.substring(0, 12) + '...' : data.attachment_filename;
                            taskFileElement.innerHTML = `<a href="db/db_view-taskfile.php?id=${taskId}&type=attachment" target="_blank" class="blue-text text"><i class="fa-solid fa-paperclip"></i> ${attachmentFilename}</a>`;
                        } else {
                            taskFileElement.innerHTML = '<span class="gray-text text"><i class="fa-solid fa-xmark"></i> No Attachment</span>';
                        }

                        document.getElementById('task_Comments').textContent = data.comments ? data.comments : 'None';
                        document.getElementById('detailsModal').style.display = 'flex';
                    }
                })
                .catch(error => console.error('Error:', error));
        });
    });
});

function closeModalDetails(modalId) {
    document.getElementById(modalId).style.display = 'none';
}